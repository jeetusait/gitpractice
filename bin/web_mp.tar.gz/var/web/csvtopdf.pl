#!/usr/bin/perl

use IO::File;
use File::Slurper 'read_text';
use DBI;
use Excel::Writer::XLSX;
use Data::Dumper;
my $infile=$ARGV[0];

my $fh=IO::File->new("<".$ARGV[0]);

my $pagetitle= 'PertSol - iLocator - MPDIAL100 Emergency Services';


my $config=do("/var/web/config.pl");

my $oradb=$config->{"mysqldb"};
my $oradb_user=$config->{"mysql_user"};
my $oradb_passwd=$config->{"mysql_passwd"};

my $mysqldb=$oradb;
my $mysql_user=$oradb_user;
my $mysql_passwd=$oradb_passwd;
my $workarea="/var/web/reportdata/";

my $dbh = DBI->connect($mysqldb, $mysql_user, $mysql_passwd, {'RaiseError' => 1});

my $seqid = $ARGV[1];
my $rowcount=0;

my $sth=$dbh->prepare("select * from reportqueue where seqid = $seqid");
$sth->execute();

my $innertable="";

my $workbook  = Excel::Writer::XLSX->new( $ARGV[0].".xlsx" );
my $worksheet = $workbook->add_worksheet();

my $format = $workbook->add_format(
        size=>12,
    border => 6,
    valign => 'vcenter',
    align  => 'center',
);

my $headformat = $workbook->add_format(
        size=>10,
    border => 1,
    valign => 'vcenter',
    align  => 'center',
        color => 'black',
        bg_color => 'cyan',
);

my $headformat1 = $workbook->add_format(
        size=>10,
    border => 1,
    valign => 'vcenter',
    align  => 'left',
        color => 'black',
        bg_color => 'cyan',
);

$format->set_bold();
$headformat->set_bold();

my $row=0;
my $col=0;

my @colwidth;

my $strow;
my $lastrow;

my $breakfield="-1";
my %rowtitle;
my %rownumeric;
my %rowcomment;
my $breakfieldval="";
my $breakfieldid=0;
my ($dopivot,$pivotrow,$pivotcol,$pivotrowid,$pivotcolid)=(0,"","",0,0);
my %pivotdata;
my %pivotcols;
my $dototal=0;
my @totalval;
my @totalcol;
my %totalcolref;
my $gtotal=0;


if(my $row=$sth->fetchrow_hashref())
{
        my $sth2=$dbh->prepare("select * from reportcustomizations where reportid is null or reportid = ".$row->{"reportid"}." order by reportid desc");
        $sth2->execute();
        while(my $row3=$sth2->fetchrow_hashref())
        {
                if($row3->{"isnumeric"} == 0)
                {
                        $rownumeric{$row3->{"columnname"}}=1;
                }

                $rowtitle{$row3->{"columnname"}}=$row3->{"displayname"};
                if(exists $row3->{"comments"})
                {
                        if(!($row3->{"comments"} eq ""))
                        {
                                $rowcomment{$row3->{"columnname"}}=$row3->{"comments"};
                        }
                }

                if(exists $row3->{"total"})
                {
                        if(!($row3->{"total"} eq ""))
                        {
                                my %totalconfig=split /[;:]/, $row3->{"total"};
                                $dototal=1;
                                foreach my $totalname(keys %totalconfig)
                                {
                                  my @totaldata=split /,/, $totalconfig{$totalname};
                                  foreach my $totcol(@totaldata)
                                  {
                                        $totalcolref{$totcol}{"name"}=$totalname;
                                  }
                                }

                        }
                }

                if($row3->{"changesheet"}==1)
                {
                        $breakfield=$row3->{"columnname"};

                }

                if($row3->{"gtotal"}==1)
                {
                        $gtotal=1;

                }

                if($row3->{"reportid"} == $row->{"reportid"})
                {
                        if(!($row3->{"pivotdata"} eq ""))
                        {
                                my %pivotconfig=split /[;:]/, $row3->{"pivotdata"};
                                if(exists $pivotconfig{"R"})
                                {
                                  if(exists $pivotconfig{"C"})
                                  {
                                        $dopivot=1;
                                        $pivotrow=$pivotconfig{"R"};
                                        $pivotcol=$pivotconfig{"C"};
                                        print "Setting pivot to 1";
                                  }
                                }

                        }
                }
        }



        my $title=$row->{"reporttitle"};
        my $params=$row->{"params"};

        $worksheet->set_row( 0, 55 );
        $worksheet->insert_image('A1','./reportdata/logo.jpg');



        $row=3;
        $col=0;
        my @paramarr=split /\n/, $params;

        foreach my $paraminfo(@paramarr)
        {
                $paramtag.="<tr>";

                my @arr=split /:/,$paraminfo;

                $paramtag.="<td align=\"left\">".$arr[0]."</td>";

                $paramtag.="<td align=\"left\">".$arr[1]."</td>";

                $paramtag.="</tr>";

                $worksheet->write_string($row,0,$arr[0],$headformat1);
                #$worksheet->write_string($row,1,$arr[1],$headformat1);
                $worksheet->merge_range_type('string',$row,1,$row,3,$arr[1],$headformat1);
                $row++;
        }

        $row++;
        $col=0;

        my $innertable="";
        my $headinfo;
        while (my $node = <$fh>) {
                chomp $node;
                if($rowcount==0)
                {
                        $rowcount=1;
                        $innertable="<thead><tr class=\"row100 head\"><th class='column100 column1' data-column='column1'>SN</th>";

                        $worksheet->write($row,$col++,'SN',$headformat);

                        my @arr=split /~/,$node;
                        $headinfo=$node;

                        foreach my $info(@arr)
                        {
                                if(!(exists $rowtitle{$info}))
                                {
                                  $rowtitle{$info}=$info;
                                }
                                else
                                {
                                  if($breakfield eq $info)
                                  {
                                        $breakfieldid=$col;
                                  }
                                }
                                if(exists $rownumeric{$info})
                                {
                                  $rownumeric{$col}=1;
                                }
                                $innertable.="<th class='column100 column1' data-column='column1'>".$rowtitle{$info}."</th>";
                                #$colwidth[$col]=0;
                                $colwidth[$col]=length($rowtitle{$info});
                                if($dopivot == 1)
                                {
                                  if($info eq $pivotrow)
                                  {
                                        $pivotrowid=$col-1;
                                  }
                                  if($info eq $pivotcol)
                                  {
                                        $pivotcolid=$col-1;
                                  }

                                }

                                if($dototal == 1)
                                {
                                  if(defined $totalcolref{$info})
                                  {
                                        $totalcolref{$info}{"id"}=$col-1;
                                        $totalcol[$col-1]=$col-1;
                                        $totalval[$col-1]=0;
                                  }
                                }

                                $worksheet->write($row,$col++,$rowtitle{$info},$headformat);
                                if(exists $rowcomment{$info})
                                {
                                  $worksheet->write_comment($row,$col-1,$rowcomment{$info});
                                }


                        }
                        print "$pivotrowid,$pivotcolid\n";

                $innertable.="</tr>
        </thead><tbody>";
                        $row++;

                        $strow=$row;

                }
                else
                {
                        my @arr=split /~/,$node;

                        if($row>5000000 || ($breakfieldid > 0 && !($breakfieldval eq $arr[$breakfieldid-1])) )
                        {
                                $lastrow=$row-1;

                                $worksheet->set_column(0,0,10);

                                my $oldworksheet=$worksheet;

                                if($breakfieldid>0 && !($breakfieldval eq $arr[$breakfieldid-1]))
                                {
                                  $breakfieldval=$arr[$breakfieldid-1];
                                }



                                for($kk=1;$kk<@colwidth;$kk++)
                                {
                                  if($colwidth[$kk]>40)
                                  {
                                        $worksheet->set_column($kk,$kk,44);
                                  }
                                  elsif($colwidth[$kk]==0)
                                  {
                                        $worksheet->set_column($kk,$kk,9);
                                  }
                                  else
                                  {
                                        $worksheet->set_column($kk,$kk,$colwidth[$kk]*1.1);

                                  }
                                }

                                $worksheet->autofilter($strow-1,0,$lastrow,(scalar @colwidth)-1);

                                $worksheet->merge_range_type('string',0,1,0,(scalar @colwidth)-1,$pagetitle,$format);

                                $worksheet->merge_range_type('string',1,0,1,(scalar @colwidth)-1,$title,$format);

                                $worksheet->set_landscape();

                                $worksheet->repeat_rows( $strow-1, $strow-1 );
                                $worksheet->set_header("&CiAnalyse - $title");
                                $worksheet->set_footer("&L&D &T&R&P-&N");
                                $worksheet->fit_to_pages( 1, 0 );

                                $row=3;

                                if($breakfieldval eq '')
                                {
                                  $worksheet = $workbook->add_worksheet();
                                }
                                else
                                {
                                  $worksheet = $workbook->add_worksheet(substr($breakfieldval,0,30));
                                }

                                if(!($worksheet->get_name() eq "Sheet1"))
                                {
                                  $worksheet->activate();

                                }
                                              print $worksheet->get_name()."\n";


                                if(!($breakfieldval eq '') )
                                {

                                  my $worksheet1=$workbook->sheets(0);

                                  $worksheet1->hide();

                                }
                                $worksheet->set_row( 0, 55 );
                                $worksheet->insert_image('A1','./reportdata/logo.jpg');

                                foreach my $paraminfo(@paramarr)
                                {

                                  my @arr=split /:/,$paraminfo;
                                  $worksheet->write_string($row,0,$arr[0],$headformat1);
                                  #$worksheet->write_string($row,1,$arr[1],$headformat1);
                                  $worksheet->merge_range_type('string',$row,1,$row,3,$arr[1],$headformat1);
                                  $row++;
                                }
                                $row++;



                                $col=0;
                                $worksheet->write($row,$col++,'SN',$headformat);


                                my @arr2=split /~/,$headinfo;

                                foreach my $info2(@arr2)
                                {
                                  $worksheet->write($row,$col++,$rowtitle{$info2},$headformat);
                                  if(exists $rowcomment{$info})
                                  {
                                        $worksheet->write_comment($row,$col-1,$rowcomment{$info2});
                                  }
                                }




                                $row++;

                                $strow=$row;

                        }

                        $innertable.="<tr class='row100'>";
                        $innertable.="<td class='column100 column1' data-column='column1'>".$rowcount."</td>";
                        $worksheet->write($row,0,$rowcount);



                        $col=1;


                        foreach my $info(@arr)
                        {
                                $innertable.="<td class='column100 column1' data-column='column1'>".$info."</td>";

                                if($row<30)
                                {
                                  if($colwidth[$col]<length($info))
                                  {
                                        $colwidth[$col]=length($info);
                                  }
                                }

                                if(exists $rownumeric{$col})
                                {
                                  $worksheet->write_string($row,$col++,$info);
                                  #print "Making $col as string \n";
                                }
                                else
                                {
                                  $worksheet->write($row,$col++,$info);
                                }




                        }
                        if($dopivot==1)
                        {
                                $pivotdata{$arr[$pivotrowid]}{$arr[$pivotcolid]}+=1;
                        }

                        if($dototal == 1)
                        {
                                foreach my $kk1(@totalcol)
                                {
                                  $totalval[$kk1]=$totalval[$kk1]+$arr[$kk1];
                                }
                        }

                        $innertable.="</tr>";
                        $rowcount+=1;
                        $row++;



                }


        }
        $innertable.="</tbody>";

        $lastrow=$row-1;

        for($kk=1;$kk<@colwidth;$kk++)
        {
                if($colwidth[$kk]>40)
                {
                        $worksheet->set_column($kk,$kk,44);
                }
                elsif($colwidth[$kk]==0)
                {
                        $worksheet->set_column($kk,$kk,9);
                }
                else
                {
                        $worksheet->set_column($kk,$kk,$colwidth[$kk]*1.1);

                }
        }

        $worksheet->set_column(0,0,10);

        $worksheet->autofilter($strow-1,0,$lastrow,(scalar @colwidth)-1);

        $worksheet->merge_range_type('string',0,1,0,(scalar @colwidth)-1,$pagetitle,$format);

        $worksheet->merge_range_type('string',1,0,1,(scalar @colwidth)-1,$title,$format);

        $worksheet->set_landscape();

        $worksheet->repeat_rows( $strow-1, $strow-1 );
        $worksheet->set_header("&CiAnalyse - $title");
        $worksheet->set_footer("&L&D&T &R&P-&N");
        $worksheet->fit_to_pages( 1, 0 );


        if($dototal == 1)
        {
                my %gtotals;
                $worksheet->write($row,0,"Total");
                foreach my $tocols(keys %totalcolref)
                {
                        $worksheet->write($row,$totalcolref{$tocols}{"id"}+1,$totalval[$totalcolref{$tocols}{"id"}]);
                        $gtotals{$totalcolref{$tocols}{"NAME"}}+=$totalval[$totalcolref{$tocols}{"id"}];
                }
                $row++;
                if($gtotal==1)
                {
                        foreach my $gtrows(keys %gtotals)
                        {
                                $worksheet->write($row,0,"Total - ".$gtrows);
                                $worksheet->write($row,1,$gtotals{$gtrows});
                                $row++;
                        }
                }
        }

        #### Section for Pivot Table

        if($dopivot == 1)
        {
                print Dumper(%pivotdata);
                my $colindex=0;
                $worksheet = $workbook->add_worksheet("Summary");
                $worksheet->set_row( 0, 55 );
                $worksheet->insert_image('A1','./reportdata/logo.jpg');
                $row=3;
                $colww=0;
                foreach my $pivotr (keys %pivotdata)
                {
                        $worksheet->write(3,$row-2,$pivotr,$headformat);
                        $worksheet->set_column($row-2,$row-2,length($pivotr)*1.1);

                        foreach my $pivotc (keys %{$pivotdata{$pivotr}})
                        {
                                if(exists $pivotcols{$pivotc})
                                {
                                  $worksheet->write($pivotcols{$pivotc}+4,$row-2,$pivotdata{$pivotr}{$pivotc});
                                }
                                else
                                {
                                  $pivotcols{$pivotc}=$colindex++;
                                  $worksheet->write($pivotcols{$pivotc}+4,$row-2,$pivotdata{$pivotr}{$pivotc});
                                  $worksheet->write($pivotcols{$pivotc}+4,0,$pivotc,$headformat);
                                  if($colww<length($pivotc))
                                  {
                                        $colww=length($pivotc);
                                  }
                                }
                        }
                        $row++;
                }

                $worksheet->set_column(0,0,$colww*1.1);

                $worksheet->activate();

                $worksheet->merge_range_type('string',0,1,0,$row-3,'PertSol - iLocator - MPDIAL100 Emergency Services',$format);

            $worksheet->merge_range_type('string',1,0,1,$row-3,$title,$format);

        }


        my $reporthtml=read_text("$workarea/report.html");
        $reporthtml =~ s/FIELDDATA/$paramtag/g;
        $reporthtml =~ s/TABLEDATA/$innertable/g;
        $reporthtml =~ s/REPORTTITLE/$title/g;


        my $fh1=IO::File->new(">".$ARGV[0].".html");
        print $fh1 $reportpdf;
        close($fh1);

        print "Rowcount is $rowcount **** \n";
        my $cmd='';
        if($rowcount<10000)
        {
                $cmd="wkhtmltopdf -O Landscape --footer-right '[page]/[toPage]' --header-center \"".$title."\" --header-spacing 3 ".$ARGV[0].".html ".$ARGV[0].".pdf";
		print $cmd;
                `$cmd`;
        }
        $workbook->close();
        #$cmd="/usr/bin/ssconvert ".$ARGV[0].".html ".$ARGV[0].".xlsx";
        #`$cmd`;
}

close($fh);

