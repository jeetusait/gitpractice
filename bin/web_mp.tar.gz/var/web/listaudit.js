

<script type="text/javascript">


$(document).ready(function() {
       var dTable =  $('#myTable').DataTable( {
         "processing": true,
         "serverSide": true,
         "ajax": {
             "url": "/lis/lis?func=auditlog",
             "type": "POST",
             "dataType":"json",
			error: function(){  // error handling
				$("#myTable").append('<tbody><tr><th colspan="5">No data found in the server</th></tr></tbody>');
				$("#myTable").css("display","none");
				
			}
             },
          "columnDefs": [
                            {
                                "targets": [5],
                                "width": "20%",
                                "visible": false
                            }
                        ]  
        } );
		$('.search-input-text').on( 'keyup click', function () {   // for text boxes
			var i =$(this).attr('data-column');  // getting column index
			var v =$(this).val();  // getting search input value
			dTable.columns(i).search(v).draw();
		} );
	});

		</script>
		
		<table id="myTable" class="display" width="100%">
		    <thead>
		        <tr>
		            <th>Session ID</th>
		            <th>Action</th>
		            <th>Outcome</th>
		            <th>Event Date</th>
		            <th>Action Logs</th>
		        </tr>
		    </thead>
					<thead>
						<tr>
							<td><input type="text" size=10 data-column="0"  class="search-input-text"></td>
							<td><input type="text" size=10 data-column="1"  class="search-input-text"></td>
							<td><input type="text" size=10 data-column="2"  class="search-input-text"></td>
							<td><input type="text" size=10 data-column="3"  class="search-input-text"></td>
							<td><input type="text" size=20 data-column="4"  class="search-input-text"></td>
							
						</tr>
					</thead>
		    
		</table>
		

		
		
		