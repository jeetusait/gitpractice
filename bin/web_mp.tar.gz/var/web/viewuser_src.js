        <div id="form"></div>
        <script type="text/javascript">
            $(document).ready(function() {
                $("#form").alpaca({
                    "data": 
						DATAJSON
                    ,
                    "schema": {
                        "title":"Create new User",
                        "description":"",
                        "type":"object",
                        "properties": {
                            "username": {
				 			    "readonly": false,
				                "required": true,
				                "type": "string",
				                "format": "email",
                            },
                            
						    "name": {
						               "type": "string",
						               "required": true,
						               "properties": {}
						           },
                            "address": {
                                "type":"string",
				               "required": true,
				               "properties": {}
                            },
							"dob": {
						                "type": "string",
						                "required": false,
						                "properties": {}
						         },
							 "changepassword": {
							                 "type": "boolean",
							                 "required": false,
							                 "default": false,
							                 "properties": {}
							             },
							 "multilogin": {
							                 "type": "boolean",
							                 "required": false,
							                 "default": false,
							                 "properties": {}
							             },
							 "locked": {
							                 "type": "boolean",
							                 "required": false,
							                 "default": false,
							                 "properties": {}
							             },
							 "rights": {
							                 "type": "object",
							                 "required": false,
							                 "properties": {
							                     "login": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     "administer": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     "query": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     
							                     "monitor": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     "report": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     "audit": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     }
							                 }
							             },
			                             "emailid1": {
			 				 			    "readonly": false,
			 				                "required": false,
			 				                "type": "string",
			 				                "format": "email",
			                             },
					    "empid": {
					               "type": "string",
					               "required": false,
					               "properties": {}
					           },
   						    "createdby": {
   						               "type": "string",
								"properties": {}
   						           },
	   						    "createdate": {
	   						               "type": "string",
									"properties": {}
	   						           },
		   						    "updatedby": {
		   						               "type": "string",
										"properties": {}
		   						           },
			   						    "updatedate": {
			   						               "type": "string",
											"properties": {}
			   						           },
	                    }
                    },
                    "options": {
                        "form":{
                            "attributes":{
                                "action":"./lis/lis?func=CreateUser",
                                "method":"post"
                            },
                            "buttons":{
                                "button":{
                                    "title": "Back",
                                    "click": function() {
                                    	window.history.go(-1);
                                    }
                                }
                            }
                        },
                        "helper": "View User",
                        "fields": {
							"username": {
							                "type": "email",
							                "validate": true,
							                "showMessages": true,
							                "label": "Email Address",
							                "helpers": [],
							                "hideInitValidationError": true,
							                "focus": true,
											"readonly":true
								
							            },
							"password": {
							                "type": "password",
							                "validate": true,
							                "showMessages": true,
							                "label": "Password Address",
							                "helpers": [],
							                "hideInitValidationError": true,
							                "focus": true
							            },		
										"name": {
										                "type": "text",
										                "validate": true,
										                "showMessages": true,
										                "label": "Name",
										                "helpers": [],
										                "hideInitValidationError": true,
										                "focus": true,
											"readonly":true
										            },	
							"address": {
							                "type": "textarea",
							                "label": "Address",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "data": {},
							                "attributes": {},
							                "allowOptionalEmpty": true,
							                "autocomplete": false,
							                "disallowEmptySpaces": false,
							                "disallowOnlyEmptySpaces": false,
							                "rows": 5,
							                "cols": 40,
							                "fields": {},
											"readonly":true
							            },
							"dob": {
							                "type": "date",
							                "label": "Date of Birth",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "data": {},
							                "attributes": {},
							                "allowOptionalEmpty": true,
							                "autocomplete": false,
							                "disallowEmptySpaces": false,
							                "disallowOnlyEmptySpaces": false,
							                "picker": {
							                    "useCurrent": false,
							                    "format": "YYYY-MM-DD",
							                    "locale": "en_US",
							                    "dayViewHeaderFormat": "MMMM YYYY",
							                    "extraFormats": []
							                },
							                "dateFormat": "YYYY-MM-DD",
							                "manualEntry": false,
							                "readonly": true,
							                "fields": {}
							            },
							"changepassword": {
							                "type": "checkbox",
							                "rightLabel": "Change Password on Next Login",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "fields": {},
											"readonly":true
											
							            },
							"multilogin": {
							                "type": "checkbox",
							                "rightLabel": "Allow Multiple Login",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "fields": {},
											"readonly":true
							            },
							"locked": {
							                "type": "checkbox",
							                "rightLabel": "User is Locked?",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "fields": {},
											"readonly":true
							            },
							"rights": {"label": "Rights Assigned to User",
			                			"type": "object",
						                "helpers": [],
						                "validate": true,
						                "disabled": false,
						                "showMessages": true,
						                "collapsible": false,
						                "legendStyle": "button",
										"fields" : {
						                     "login": {
	 							                "type": "checkbox",
	 							                "rightLabel": "Login to System",
	 							                "helpers": [],
	 							                "validate": true,
	 							                "disabled": false,
	 							                "showMessages": true,
	 							                "renderButtons": true,
	 							                "fields": {},
											"readonly":true
						                     },
						                     "administer": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "Administrator",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {},
											"readonly":true
						                     },
						                     "query": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "Target Management",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {},
											"readonly":true
						                     },
						                     "monitor": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "Monitor System",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {},
											"readonly":true
						                     },
						                     "report": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "View Reports",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {},
											"readonly":true
						                     },
						                     "audit": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "See Audit Log",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {},
											"readonly":true
						                     }
										},
							
							},
							"emailid1": {
							                "type": "email",
							                "validate": true,
							                "showMessages": true,
							                "label": "Secondary Email Address",
							                "helpers": [],
							                "hideInitValidationError": false,
							                "focus": true,
											"readonly":true
							            },
							"empid": {
							                "type": "text",
							                "validate": true,
							                "showMessages": true,
							                "label": "Employee ID",
							                "helpers": [],
							                "hideInitValidationError": false,
							                "focus": true,
											"readonly":true
							            },
										"createdby": {
										                "type": "text",
										                "validate": true,
										                "showMessages": true,
										                "label": "Created by",
										                "helpers": [],
										                "hideInitValidationError": false,
										                "focus": true,
														"readonly":true
										            },
													"createdate": {
													                "type": "text",
													                "validate": true,
													                "showMessages": true,
													                "label": "Create date",
													                "helpers": [],
													                "hideInitValidationError": false,
													                "focus": true,
																	"readonly":true
													            },
																"updatedby": {
																                "type": "text",
																                "validate": true,
																                "showMessages": true,
																                "label": "Updated By",
																                "helpers": [],
																                "hideInitValidationError": false,
																                "focus": true,
																				"readonly":true
																            },
																			"updatedate": {
																			                "type": "text",
																			                "validate": true,
																			                "showMessages": true,
																			                "label": "Update Date",
																			                "helpers": [],
																			                "hideInitValidationError": false,
																			                "focus": true,
																							"readonly":true
																			            },
                        }
                    },
                    "postRender": function(control) {
                        //control.childrenByPropertyId["name"].getFieldEl().css("background-color", "lightgreen");
                    }
                });
            });
        </script>