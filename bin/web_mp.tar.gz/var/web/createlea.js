        <div id="form"></div>
        <script type="text/javascript">
$('#form').alpaca({
    "schema": {
                        "title":"Live location Query",
                        "description":"",
        "type": "object",
        "required": false,
        "properties": {
            "mobileno": {
                "type": "string",
                "required": false,
                "properties": {}
            }
        }
    },
    "options": {
        "form":{
            "attributes":{
                "action":"./lis/lis?func=getlocation",
                "method":"post"
            },
            "buttons":{
                "submit":{
                    "title": "Get Location",
                    "click": function() {
                        var val = this.getValue();
						
                        if (this.isValid(true)) {
                            //alert("Valid value: " + JSON.stringify(val, null, "  "));
                            this.ajaxSubmit().done(function(html) {
								//var resp=JSON.parse(html.getValue());
								//alert(html.status);
								if(html.status=="Logout")
								{
									alert(html.reason);
									window.location=html.redirect;
								}
								else if(html.status=="Failed")
								{
									alert("Location Not Available : "+html.reason);
								}
								else
								{
									alert(html.reason);
									
									$("#add_err").html("Latitude : "+html.latitude+"<BR>"+"Longitude : "+html.longitude+"<BR>"+"Address : "+html.address1+"<BR>"+"Name : "+html.name+"<BR>"+"<iframe width='300' height='170' frameborder='0' scrolling='no' marginheight='0' marginwidth='0'  src='https://maps.google.com/maps?q="+html.latitude+","+html.longitude+"&hl=es;z=14&amp;output=embed'> </iframe><br /> <small> <a href='https://maps.google.com/maps?q="+html.latitude+","+html.longitude+"&hl=es;z=14&amp;output=embed'      style='color:#0000FF;text-align:left'      target='_blank'    >      See map bigger    </a> </small>");
								}
                            });
                        } else {
                            alert("Invalid value: " + JSON.stringify(val, null, "  "));
                        }
                    }
                }
            }
		},
        "focus": false,
        "type": "object",
        "helpers": [],
        "validate": true,
        "disabled": false,
        "showMessages": true,
        "collapsible": false,
        "legendStyle": "button",
        "fields": {
            "mobileno": {
                "type": "text",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "Target Number",
                "helpers": [
                    "Enter Number to Search prefix with 91 for Indian Number"
                ],
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [],
                "name": "leaname",
                "typeahead": {},
                "allowOptionalEmpty": false,
                "data": {},
                "autocomplete": false,
                "disallowEmptySpaces": true,
                "disallowOnlyEmptySpaces": true,
                "fields": {},
                "renderButtons": true,
                "attributes": {}
            }
        }
    },
    "data": {}
});
</script>

<div class="text-center p-t-136">
							<div id="add_err">

</div>
					</div>
