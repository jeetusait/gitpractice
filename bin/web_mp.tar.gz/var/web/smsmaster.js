		<script type="text/javascript" charset="utf-8" src="/js/table.smsmaster.js"></script>
		
		<div class="container">

			<h1>
				DataTables Editor <span>smsmaster</span>
			</h1>
			
			<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="smsmaster" width="100%">
				<thead>
					<tr>
						<th>msisdn</th>
						<th>belongsto</th>
					</tr>
				</thead>
			</table>

		</div>