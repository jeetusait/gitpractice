

<script type="text/javascript">
function format ( rowData ) {
	var div = $('<div/>')
		.addClass( 'loading' )
		.text( 'Loading...' );

	$.ajax( {
		url: '/lis/lis?func=GetUserOpt&form=ListLEA',
		data: {
			name: rowData.name
		},
		dataType: 'json',
		type: 'post',
		success: function ( json ) {
			div
				.html( json.html )
				.removeClass( 'loading' );
		} 
	} );

	return div;
}


$(document).ready(function() {
	var table = $('#myTable').DataTable( {
		"ajax": "/lis/lis?func=ListLEA",
		"columns": [
			{
				"className":      'details-control',
				"orderable":      false,
				"data":           null,
				"defaultContent": ''
			},
			{ "data": "id" },
			{ "data": "name" },
			{ "data": "count" },
			
		],
		"order": [[1, 'asc']]
	} );
	
	// Add event listener for opening and closing details
	$('#myTable tbody').on('click', 'td.details-control', function () {
		var tr = $(this).closest('tr');
		var row = table.row( tr );

		if ( row.child.isShown() ) {
			// This row is already open - close it
			row.child.hide();
			tr.removeClass('shown');
		}
		else {
			// Open this row
			row.child( format(row.data()) ).show();
			tr.addClass('shown');
		}
	} );
} );

		</script>
		
		<table id="myTable" class="display" width="50%">
		    <thead>
		        <tr>
		            <th></th>
		            <th>Username</th>
		            <th>Name</th>
		            <th>Target Count</th>
					
		        </tr>
		    </thead>
					
		</table>
		

		
		
		