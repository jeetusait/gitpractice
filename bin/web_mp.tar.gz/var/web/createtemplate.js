
        <div id="form"></div>
        <script type="text/javascript">
            $(document).ready(function() {
                $("#form").alpaca({
                    "data": {
                    },
                    "schema": {
                        "title":"Create Template",
                        "description":"",
                        "type":"object",
                        "properties": {
                            "tempname": {
				 			    "readonly": false,
				                "required": true,
				                "type": "string"
							},
						    "colsep": {
						               "type": "string",
						               "required": true,
						               "properties": {},
                "minLength": 1,
                "maxLength": 10,
						           },
							 "printhead": {
							                 "type": "boolean",
							                 "required": false,
							                 "default": true,
							                 "properties": {}
							             },
							 "daywisefiles": {
							                 "type": "boolean",
							                 "required": false,
							                 "default": true,
							                 "properties": {}
							             },
							 			"rowsep": {
							                 "readonly": false,
							                 "required": true,
							                 "disallow": [],
							                 "enum": [
							                     "CRLF",
							                     "CR",
							                     "LF"
							                 ],
							                 "properties": {}
							             },
							             "fieldlist1": {
							                 "required": false,
							                 "properties": {}
							             },
				               
	                    }
                    },
                    "options": {
                        "form":{
                            "attributes":{
                                "action":"./lis/lis?func=createtemplate",
                                "method":"post"
                            },
                            "buttons":{
                                "submit":{
                                    "title": "Add Template",
                                    "click": function() {
                                        var val = this.getValue();
                                        if (this.isValid(true)) {
                                            alert("Valid value: " + JSON.stringify(val, null, "  "));
                                            this.ajaxSubmit().done(function(html) {
												//var resp=JSON.parse(html.getValue());
												if(html.status=="Logout")
												{
													window.location=html.redirect;
												}
												alert(html.reason);
												
												
                                            });
                                        } else {
                                            alert("Invalid value: " + JSON.stringify(val, null, "  "));
                                        }
                                    }
                                }
                            }
                        },
                        "helper": "Let us create new template",
                        "fields": {
							"tempname": {
							                "type": "text",
							                "showMessages": true,
							                "label": "Template Name",
							                "helpers": [],
							                "hideInitValidationError": false,
							                "focus": true
							            },
										"colsep": {
										                "type": "text",
										                "validate": true,
										                "showMessages": true,
										                "label": "Column Separator",
										                "helpers": [],
										                "hideInitValidationError": false,
										                "focus": true
										            },	
							"printhead": {
							                "type": "checkbox",
							                "rightLabel": "Print Header",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "fields": {}
							            },
							"daywisefiles": {
							                "type": "checkbox",
							                "rightLabel": "Generate Day Wise Files",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "fields": {}
							            },
							"locked": {
							                "type": "checkbox",
							                "rightLabel": "User is Locked?",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "fields": {}
							            },
										"rowsep": {
										                "type": "radio",
										                "validate": true,
										                "showMessages": false,
										                "disabled": false,
										                "hidden": false,
										                "label": "Row Separator",
										                "helpers": [],
										                "hideInitValidationError": false,
										                "focus": true,
										                "optionLabels": [
										                    "CRLF (Windows)",
										                    "CR",
										                    "LF (Linux/Unix)"
										                ],
										                "removeDefaultNone": true,
										                "noneLabel": "None",
										                "hideNone": true,
										                "useDataSourceAsEnum": true,
										                "emptySelectFirst": true,
										                "vertical": false,
										                "readonly": false,
										                "renderButtons": true,
										                "fields": {}
										            },
							"fieldlist1": {
								"type": "chooser",
				                "label": "Output Fields",
"helpers": [],
								"height": "200px",
                "helpersPosition": "right",
                "validate": true,
                "disabled": false,
                "showMessages": true,
                "renderButtons": true,
							       	 "dataSource": "/lis/lis?func=getfieldlist"
							    },
                        }
                    },
                    "postRender": function(control) {
                        //control.childrenByPropertyId["name"].getFieldEl().css("background-color", "lightgreen");
                    }
                });
            });
        </script>
   