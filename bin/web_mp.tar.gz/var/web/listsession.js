

<script type="text/javascript">


$(document).ready(function() {
       var dTable =  $('#myTable').DataTable( {
		   "scrollX": true,
         "processing": true,
         "serverSide": true,
		            "ajax": {
             "url": "/lis/lis?func=sessionlog",
             "type": "POST",
             "dataType":"json",
			error: function(){  // error handling
				$("#myTable").append('<tbody><tr><th colspan="7">No data found in the server</th></tr></tbody>');
				$("#myTable").css("display","none");
				
			}
             },	
			 "columnDefs": [
			                              {
			                                  "targets": [7],
			                                  "width": "20%",
			                                  "visible": false
			                              }
			                          ]  		 
        } );
		$('.search-input-text').on( 'keyup click', function () {   // for text boxes
			var i =$(this).attr('data-column');  // getting column index
			var v =$(this).val();  // getting search input value
			dTable.columns(i).search(v).draw();
		} );
		
	});

		</script>
		
		<table id="myTable" class="display" width="100%">
		    <thead>
		        <tr>
		            <th>Audit Session ID</th>
		            <th>Name</th>
		            <th>Username</th>
		            <th>IP Address</th>
		            <th>Login Time</th>
		            <th>Last Access</th>
		            <th>Logout Time</th>
		        </tr>
		    </thead>
					<thead>
						<tr>
							<td><input type="text" size=10 data-column="0"  class="search-input-text"></td>
							<td><input type="text" size=10 data-column="1"  class="search-input-text"></td>
							<td><input type="text" size=10 data-column="2"  class="search-input-text"></td>
							<td><input type="text" size=10 data-column="3"  class="search-input-text"></td>
							<td><input type="text" size=10 data-column="4"  class="search-input-text"></td>
							<td><input type="text" size=10 data-column="5"  class="search-input-text"></td>
							<td><input type="text" size=10 data-column="6"  class="search-input-text"></td>
						</tr>
					</thead>
		    
		</table>
		

		
		
		