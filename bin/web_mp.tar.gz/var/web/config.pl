{
                mysqldb=>"DBI:mysql:database=LISDB;host=localhost",
                mysql_user=>"lis",
                mysql_passwd=>"lis\@4321",
                logpath=>"/root/logs",
                deckey=>"Godisgreat!",
                waittime=>60,
}
