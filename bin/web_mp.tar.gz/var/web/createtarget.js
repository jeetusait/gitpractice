<div id="form"></div>
<script type="text/javascript">

$.alpaca.Fields.CustomField = $.alpaca.Fields.TextField.extend({
    getFieldType: function() {
        return "checkbox";
    },
    onChange: function(e) {
		if(this.name == "copydata")
		{
		this.getParent().childrenByPropertyId["psiriip"].setValue(this.getParent().childrenByPropertyId["cciriip"].getValue());
		this.getParent().childrenByPropertyId["psirimode"].setValue(this.getParent().childrenByPropertyId["ccirimode"].getValue());
		this.getParent().childrenByPropertyId["psiriusername"].setValue(this.getParent().childrenByPropertyId["cciriusername"].getValue());
		this.getParent().childrenByPropertyId["psiripassword"].setValue(this.getParent().childrenByPropertyId["cciripassword"].getValue());
		this.getParent().childrenByPropertyId["psiriftppath"].setValue(this.getParent().childrenByPropertyId["cciriftppath"].getValue());
		}
		if(this.name == "copydata1")
		{
			this.getParent().childrenByPropertyId["pdiriip"].setValue(this.getParent().childrenByPropertyId["psiriip"].getValue());
			this.getParent().childrenByPropertyId["pdirimode"].setValue(this.getParent().childrenByPropertyId["psirimode"].getValue());
			this.getParent().childrenByPropertyId["pdiriusername"].setValue(this.getParent().childrenByPropertyId["psiriusername"].getValue());
			this.getParent().childrenByPropertyId["pdiripassword"].setValue(this.getParent().childrenByPropertyId["psiripassword"].getValue());
			this.getParent().childrenByPropertyId["pdiriftppath"].setValue(this.getParent().childrenByPropertyId["psiriftppath"].getValue());
		}
    }
});
Alpaca.registerFieldClass("checkbox", Alpaca.Fields.CustomField);

    $(document).ready(function() {
$('#form').alpaca({
    "schema": {
        "type": "object",
        "required": false,
        "properties": {
			"configname": {
				"readonly": true,
                "required": true,
                "type": "any",
                "disallow": [],
				"properties": {}
			            },
			"targettype": {
                "readonly": false,
                "required": true,
                "disallow": [],
                "enum": [
                    "IMEI",
                    "IMSI",
                    "IPAddress",
                    "MSISDN",
                    "SIPAddress"
                ],
                "properties": {}
            },
            "imei": {
                "readonly": false,
                "required": true,
                "type": "integer",
                "disallow": [],
                "minLength": 14,
                "maxLength": 16,
                "exclusiveMinimum": false,
                "exclusiveMaximum": false,
                "properties": {}
            },
            "ipaddress": {
                "readonly": false,
                "required": true,
                "type": "string",
                "disallow": [],
            },
            "msisdn": {
                "readonly": false,
                "required": true,
                "type": "integer",
                "disallow": [],
                "minLength": 8,
                "maxLength": 15,
                "exclusiveMinimum": false,
                "exclusiveMaximum": false,
                "properties": {}
            },
            "imsi": {
                "readonly": false,
                "required": true,
                "type": "integer",
                "disallow": [],
                "minLength": 15,
                "maxLength": 15,
                "exclusiveMinimum": false,
                "exclusiveMaximum": false,
                "properties": {}
            },
            "sipaddress": {
                "readonly": false,
                "required": true,
                "type": "string",
                "disallow": [],
                "minLength": 5,
                "properties": {}
            },
            "fanoutno": {
                "readonly": false,
                "required": false,
                "type": "string",
                "disallow": [],
                "exclusiveMinimum": false,
                "exclusiveMaximum": false,
                "properties": {}
            },
            "liid": {
                "readonly": false,
                "required": false,
                "type": "number",
                "disallow": [],
                "exclusiveMinimum": false,
                "exclusiveMaximum": false,
                "properties": {}
            },
			
            "startdate": {
                "type": "string",
                "required": false,
                "properties": {}
            },
            
			"period": {
                "readonly": false,
                "required": true,
                "disallow": [],
                "enum": [
                    "enddate",
                    "period",
                    "predefined"
                ],
                "properties": {}
            },
            "enddate": {
                "type": "string",
                "required": false,
                "properties": {}
            },
            "perioddays": {
                "type": "integer",
                "required": false,
                "minLength": 1,
                "maxLength": 3,
                "properties": {}
            },
            "predefined": {
                "readonly": false,
                "required": true,
                "disallow": [],
                "enum": [
                    "7",
                    "15",
                    "31",
					"45",
					"60",
					"90",
					"180",
					"365"
                ],
                "properties": {}
            },
            "letterdate": {
                "type": "string",
                "required": false,
                "properties": {}
            },
            "warrantno": {
                "readonly": false,
                "required": true,
                "type": "string",
                "disallow": [],
                "minLength": 5,
                "properties": {}
            },
            "nodelist": {
                "readonly": false,
                "required": true,
                "type": "string",
                "disallow": [],
                "properties": {}
            },
			"warrantcopy": {
			                "type": "string",
			                "required": false,
			                "properties": {}
			            },
            "ccirimode": {
                "readonly": false,
                "required": true,
                "disallow": [],
                "enum": [
                    "7",
                    "1",
                    "3",
					"15",
					"31"
                ],
                "properties": {}
            },
            //IRI-1
			//CC-2
			//PS-4
			//RecVideo-8
			//RecAll-16
    },
	"dependencies": {
	            "imei": ["targettype"],
	            "ipaddress": ["targettype"],
	            "msisdn": ["targettype"],
	            "imsi": ["targettype"],
		"sipaddress": ["targettype"],
		"enddate": ["period"],
		"perioddays": ["period"],
		"predefined": ["period"]	        }
},
    "options": {
        "focus": false,
        "type": "object",
        "helpers": [],
        "validate": true,
        "disabled": false,
        "showMessages": true,
        "collapsible": false,
        "legendStyle": "button",
        "form":{
            "attributes":{
                "action":"/lis/lis?func=CreateTarget",
                "method":"post"
			},
            "buttons":{
                "button":{
                    "title": "Go Back",
                    "click": function() {
                    	window.history.go(-1);
                    }
                },
                "button1":{
                    "title": "Get New LIID",
                    "click": function() {
						var request = $.ajax({
						  url: "/lis/lis?func=getnewliid",
						  type: "POST",
						  dataType: "json"
						});

						request.done(function(html) {
							var control = $("#form").alpaca("get");
							var obj=control.childrenByPropertyId["liid"];
							obj.setValue(html.liid);
						});
                    }
                },
                "submit":{
                    "title": "Create Target",
                    "click": function() {
                        var val = this.getValue();
                        if (this.isValid(true)) {
                            alert("Valid value: " + JSON.stringify(val, null, "  "));
                            this.ajaxSubmit().done(function(html) {
								if(html.status=="Logout")
								{
									alert(html.reason);
									window.location=html.redirect;
								}
								else if(html.status=="Failed")
								{
									alert("MC not Created : See Error Pane");
									$("#add_err").css('display', 'inline', 'important');
									 $("#add_err").html(html.reason);
								}
								else
								{
									alert(html.reason);
								}
			
			
                            });
                        } else {
                            alert("Invalid value: " + JSON.stringify(val, null, "  "));
                        }
                    }
                }
            }
       },
        "fields": {
			"configname": {
				"type": "optiontree",
                "label": "Select Monitoring Center",
                "tree": {
                    "selectors": {                 
						"lea": {
                    "schema": {
                        "type": "string"
                    },
                    "options": {
                        "type": "select",
                        "noneLabel": "Select LEA",
						"label" : "Select LEA"
                    }
				},
					"mc": {
					                    "schema": {
					                        "type": "string"
					                    },
					                    "options": {
					                        "type": "select",
					                        "noneLabel": "Monitoring Center",
											"label" : "Select MC"
					                    }
									}
				},
                    "order": ["lea","mc"],
				"data": LISTDATA,
                    "horizontal": true
                },
                "fields": {},
                "readonly": false
			},
			"targettype": {
			                "type": "radio",
			                "validate": true,
			                "showMessages": false,
			                "disabled": false,
			                "hidden": false,
			                "label": "Target Type",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [
			                    "IMEI",
			                    "IMSI",
			                    "IP address",
			                    "MSISDN",
			                    "SIP Address"
			                ],
			                "removeDefaultNone": true,
			                "noneLabel": "None",
			                "hideNone": true,
			                "useDataSourceAsEnum": true,
			                "emptySelectFirst": false,
			                "vertical": false,
			                "readonly": false,
			                "renderButtons": true,
			                "fields": {}
			            },
						"predefined": {
						                "type": "radio",
						                "validate": true,
						                "showMessages": true,
						                "disabled": false,
						                "hidden": false,
						                "label": "Target Activity Period",
						                "helpers": [],
						                "hideInitValidationError": false,
						                "focus": true,
						                "optionLabels": [
						                    "1 Week",
						                    "Fortnight",
						                    "One Month",
						                    "45 Days",
						                    "2 Months",
											"3 Months",
											"6 Months",
											"1 Year"
						                ],
						                "removeDefaultNone": true,
						                "noneLabel": "None",
						                "hideNone": true,
						                "useDataSourceAsEnum": true,
						                "emptySelectFirst": false,
						                "vertical": false,
						                "readonly": false,
						                "renderButtons": true,
						                "fields": {},
										"dependencies": {
										                    "period": "predefined"
										                }
						            },
									"ccirimode": {
									                "type": "radio",
									                "validate": true,
									                "showMessages": true,
									                "disabled": false,
									                "hidden": false,
									                "label": "CC IRI Mode",
									                "helpers": [],
									                "hideInitValidationError": false,
									                "focus": true,
									                "optionLabels": [
									                    "IRI CC & PD",
									                    "IRI Only",
									                    "IRI CC without PD",
									                    "Record Video Calls",
									                    "Record All Calls with IRI CC & PD"
									                ],
									                "removeDefaultNone": true,
									                "noneLabel": "None",
									                "hideNone": true,
									                "useDataSourceAsEnum": true,
									                "emptySelectFirst": false,
									                "vertical": false,
									                "readonly": false,
									                "renderButtons": true,
									                "fields": {}
									            },
			            "imei": {
			                "type": "integer",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "IMEI",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "imei",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": true,
			                "disallowOnlyEmptySpaces": true,
			                "numericEntry": true,
			                "slider": false,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": false,
			                "fields": {},
							"dependencies": {
							                    "targettype": "IMEI"
							                }
			            },
			            "perioddays": {
			                "type": "integer",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "Period in Days",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "perioddays",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": true,
			                "disallowOnlyEmptySpaces": true,
			                "numericEntry": true,
			                "slider": false,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": false,
			                "fields": {},
							"dependencies": {
							                    "period": "period"
							                }
			            },
			            "ipaddress": {
			                "type": "ipv4",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "IP Address",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "ipaddress",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": false,
			                "disallowOnlyEmptySpaces": false,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": false,
			                "fields": {},
							"dependencies": {
							                    "targettype": "IPAddress"
							                }
			            },
			            "msisdn": {
			                "type": "integer",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "MSISDN/ISDN",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "msisdn",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": true,
			                "disallowOnlyEmptySpaces": true,
			                "numericEntry": true,
			                "slider": false,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": false,
			                "fields": {},
							"dependencies": {
							                    "targettype": "MSISDN"
							                }
			            },
			            "imsi": {
			                "type": "integer",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "IMSI",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "imsi",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": false,
			                "disallowOnlyEmptySpaces": false,
			                "numericEntry": false,
			                "slider": false,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": false,
			                "fields": {},
							"dependencies": {
							                    "targettype": "IMSI"
							                }
			            },
			            "sipaddress": {
			                "type": "text",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "SIP Address",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "sipaddress",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": false,
			                "disallowOnlyEmptySpaces": false,
			                "readonly": false,
			                "renderButtons": true,
			                "attributes": {},
			                "fields": {},
							"dependencies": {
							                    "targettype": "SIPAddress"
							                }
			            },
			         
			            "warrantno": {
			                "type": "text",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "Enter Provisioning Request Details",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "warratno",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": false,
			                "disallowOnlyEmptySpaces": false,
			                "readonly": false,
			                "renderButtons": true,
			                "attributes": {},
			                "fields": {}
			            },
			            "liid": {
			                "type": "number",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "Lawful Interception Identifier",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "liid",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": true,
			                "disallowOnlyEmptySpaces": true,
			                "numericEntry": false,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": false,
			                "fields": {}
			            },
			            "fanoutno": {
			                "type": "text",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "Fanout No",
			                "helpers": ["Overrides Monitoring Center Setting", "Enter multiple fanout nos with separator as ; (semicolon)"],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "fanoutno",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": true,
			                "disallowOnlyEmptySpaces": true,
			                "numericEntry": true,
			                "slider": false,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": false,
			                "fields": {}
			            },
			            "startdate": {
							"type": "datetime",
			                "label": "Target Activation Start Date",
			                "helpers": [],
			                "validate": true,
			                "disabled": false,
			                "showMessages": true,
			                "renderButtons": true,
			                "data": {},
			                "attributes": {},
			                "allowOptionalEmpty": true,
			                "autocomplete": false,
			                "disallowEmptySpaces": false,
			                "disallowOnlyEmptySpaces": false,
			                "picker": {
			                    "useCurrent": true,
			                    "format": "YYYY-MM-DD HH:mm:ss",
			                    "locale": "en_US",
			                    "dayViewHeaderFormat": "MMMM YYYY",
			                    "extraFormats": [
			                        "MM/DD/YYYY hh:mm:ss a",
			                        "MM/DD/YYYY HH:mm",
			                        "MM/DD/YYYY"
			                    ]
			                },
			                "dateFormat": "YYYY-MM-DD HH:mm:ss",
			                "manualEntry": false,
			                "fields": {}
			            },
			            "enddate": {
							"type": "datetime",
			                "label": "Target Activation End Date",
			                "helpers": [],
			                "validate": true,
			                "disabled": false,
			                "showMessages": true,
			                "renderButtons": true,
			                "data": {},
			                "attributes": {},
			                "allowOptionalEmpty": true,
			                "autocomplete": false,
			                "disallowEmptySpaces": false,
			                "disallowOnlyEmptySpaces": false,
			                "picker": {
			                    "useCurrent": false,
			                    "format": "YYYY-MM-DD HH:mm:ss",
			                    "locale": "en_US",
			                    "dayViewHeaderFormat": "MMMM YYYY",
			                    "extraFormats": [
			                        "MM/DD/YYYY hh:mm:ss a",
			                        "MM/DD/YYYY HH:mm",
			                        "MM/DD/YYYY"
			                    ]
			                },
			                "dateFormat": "YYYY-MM-DD HH:mm:ss",
			                "manualEntry": false,
			                "fields": {},
							"dependencies": {
							                    "period": "enddate"
							                }
			            },
						"period": {
						                "type": "radio",
						                "validate": true,
						                "showMessages": true,
						                "disabled": false,
						                "hidden": false,
						                "label": "Target Activity Period :",
						                "helpers": [],
						                "hideInitValidationError": false,
						                "focus": true,
						                "optionLabels": [
						                    "Enter End Date",
						                    "Enter No of Days",
						                    "Enter Predefined Period"
						                ],
						                "removeDefaultNone": true,
						                "noneLabel": "None",
						                "hideNone": true,
						                "useDataSourceAsEnum": true,
						                "emptySelectFirst": false,
						                "vertical": false,
						                "readonly": false,
						                "renderButtons": true,
						                "fields": {}
						            },
						            "letterdate": {
										"type": "date",
						                "label": "Warrant Date",
						                "helpers": [],
						                "validate": true,
						                "disabled": false,
						                "showMessages": true,
						                "renderButtons": true,
						                "data": {},
						                "attributes": {},
						                "allowOptionalEmpty": true,
						                "autocomplete": false,
						                "disallowEmptySpaces": false,
						                "disallowOnlyEmptySpaces": false,
						                "picker": {
						                    "useCurrent": false,
						                    "format": "YYYY-MM-DD",
						                    "locale": "en_US",
						                    "dayViewHeaderFormat": "MMMM YYYY"
						                },
						                "dateFormat": "YYYY-MM-DD",
						                "manualEntry": false,
						                "fields": {}
						            },
									"warrantcopy": {
									                "type": "file",
									                "label": "Upload file in respect to Provisioning Request",
									                "helpers": [],
									                "validate": true,
									                "disabled": false,
									                "showMessages": true,
									                "renderButtons": true,
									                "data": {},
									                "attributes": {},
									                "allowOptionalEmpty": true,
									                "autocomplete": false,
									                "disallowEmptySpaces": false,
									                "disallowOnlyEmptySpaces": false,
									                "fields": {}
									            },
												
							"nodelist": {
							        "label": "Provisioning Nodes",
							        "helper": "Select Nodes where target to be provisioned",
							        "type": "select",
								"fieldClass": "nodelister",
			                		"showMessages": false,
									"multiselect": {
								                    "enableFiltering": true,
								                    "includeSelectAllOption": true,
            										"dropUp": true,
										"numberDisplayed": 10,
										"selectAllText": 'Provision on All Nodes',
										"maxHeight" : 200
								                },
							        "multiple": true,
							        "dataSource": "/lis/lis?func=getnodelist",
              						"hideInitValidationError": true
							    }
		},
    },
    "data": MASTERDATA,
	"view": {
	        "parent": "bootstrap-edit-horizontal",
	        "wizard": {
	            "title": "Create New Target",
	            "description": "Create Target",
				"hideSubmitButton": true,
	            "bindings": {
	                "configname": 1,
					"targettype" : 1,
	                "msisdn": 1,
	                "imsi": 1,
	                "imei": 1,
	                "ipaddress": 1,
					"sipaddress" : 1,
					"fanoutno": 1,
					"ccirimode" : 1,
					"nodelist" : 1,
					"liid" : 2,
					"startdate" : 2,
					"period" : 2,
					"enddate" : 2,
					"perioddays" : 2,
					"predefined": 2,
					"letterdate" : 3,
					"warrantno" : 3,
					"warrantcopy" : 3,
	            },
	            "steps": [{
	                "title": "Target Details",
	                "description": "Enter Target Basic Information"
	            }, {
	                "title": "Target LIID and Period",
	                "description": ""
	            }, {
	                "title": "Warrant Details",
	                "description": "Warrant Reference Details"
	            }],
					        
	        }
	    }
});
});
</script>
<div class="text-center p-t-136">
						<a class="txt2" href="#">
							<div class="err" id="add_err"></div>
						</a>
					</div>


