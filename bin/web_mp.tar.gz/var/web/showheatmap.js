 <div id="form"></div>
        <script type="text/javascript">
$('#form').alpaca({
    "schema": {
                        "title":"Show Heat Map Based on Location Data for Calls Received by iLocate (CAD)",
                        "description":"",
        "type": "object",
        "required": false,
        "properties": {
            "startdate": {
                "type": "string",
                "required": false,
                "properties": {}
            },
            "enddate": {
                "type": "string",
                "required": false,
                "properties": {}
            }
			
        }
    },
    "options": {
        "form":{
            "attributes":{
                "action":"/lis/lis?func=showheatmap",
                "method":"post"
            },
            "buttons":{
	            "submit":{
	                "title": "Show based on Dates",
	            },
				"button":{
				                    "title": "Current Hour",
				                    "click": function() {
				                    	window.location="/lis/lis?func=showheatmap&period=hour";
				                    }
				                },
				"button1":{
				                    "title": "Today",
				                    "click": function() {
				                    	window.location="/lis/lis?func=showheatmap&period=day";
				                    }
				                },
				"button2":{
				                    "title": "Since Last Hour",
				                    "click": function() {
				                    	window.location="/lis/lis?func=showheatmap&period=lhour";
				                    }
				                }
								
            }
		},
        "focus": false,
        "type": "object",
        "helpers": [],
        "validate": true,
        "disabled": false,
        "showMessages": true,
        "collapsible": false,
        "legendStyle": "button",
        "fields": {
            "startdate": {
							"type": "datetime",
			                "label": "Select Start Date",
			                "helpers": [],
			                "validate": true,
			                "disabled": false,
			                "showMessages": true,
			                "renderButtons": true,
			                "data": {},
			                "attributes": {},
			                "allowOptionalEmpty": true,
			                "autocomplete": false,
			                "disallowEmptySpaces": false,
			                "disallowOnlyEmptySpaces": false,
			                "picker": {
			                    "useCurrent": true,
			                    "format": "YYYY-MM-DD",
			                    "locale": "en_US",
			                    "dayViewHeaderFormat": "MMMM YYYY",
			                    "extraFormats": [
			                        "MM/DD/YYYY hh:mm:ss a",
			                        "MM/DD/YYYY HH:mm",
			                        "MM/DD/YYYY"
			                    ]
			                },
			                "dateFormat": "YYYY-MM-DD HH:mm:ss",
			                "manualEntry": true,
			                "fields": {},
			            },
			            "enddate": {
										"type": "datetime",
						                "label": "Select Start Date",
						                "helpers": [],
						                "validate": true,
						                "disabled": false,
						                "showMessages": true,
						                "renderButtons": true,
						                "data": {},
						                "attributes": {},
						                "allowOptionalEmpty": true,
						                "autocomplete": false,
						                "disallowEmptySpaces": false,
						                "disallowOnlyEmptySpaces": false,
						                "picker": {
						                    "useCurrent": true,
						                    "format": "YYYY-MM-DD",
						                    "locale": "en_US",
						                    "dayViewHeaderFormat": "MMMM YYYY",
						                    "extraFormats": [
						                        "MM/DD/YYYY hh:mm:ss a",
						                        "MM/DD/YYYY HH:mm",
						                        "MM/DD/YYYY"
						                    ]
						                },
						                "dateFormat": "YYYY-MM-DD HH:mm:ss",
						                "manualEntry": true,
						                "fields": {},
						            }
        }
    },
    "data": {}
});
</script>

<div class="text-center p-t-136">
							<div id="add_err">

</div>
					</div>

