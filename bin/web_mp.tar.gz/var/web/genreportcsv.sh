#!/bin/bash

export PATH=$PATH:/usr/local/bin:
cd /var/web
nohup ./genreportcsv.pl $1 &
