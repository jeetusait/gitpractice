
        <div id="form"></div>
        <script type="text/javascript">
            $(document).ready(function() {
                $("#form").alpaca({
                    "data": {
                    },
                    "schema": {
                        "title":"Create new User",
                        "description":"",
                        "type":"object",
                        "properties": {
                            "username": {
				 			    "readonly": false,
				                "required": true,
				                "type": "string",
				                "format": "email",
                            },
                            "password": {
				 			    "readonly": false,
				                "required": true,
				                "type": "string",
				                "format": "password",
                            },
						    "name": {
						               "type": "string",
						               "required": true,
						               "properties": {}
						           },
                            "address": {
                                "type":"string",
				               "required": true,
				               "properties": {}
                            },
							"dob": {
						                "type": "string",
						                "required": false,
						                "properties": {}
						         },
							 "changepassword": {
							                 "type": "boolean",
							                 "required": false,
							                 "default": false,
							                 "properties": {}
							             },
							 "multilogin": {
							                 "type": "boolean",
							                 "required": false,
							                 "default": false,
							                 "properties": {}
							             },
							 "locked": {
							                 "type": "boolean",
							                 "required": false,
							                 "default": false,
							                 "properties": {}
							             },
							 "rights": {
							                 "type": "object",
							                 "required": false,
							                 "properties": {
							                     "login": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     "administer": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     "query": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     "monitor": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     "report": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     },
							                     "audit": {
							                         "type": "boolean",
							                         "required": false,
							                         "properties": {}
							                     }
							                 }
							             },
		  				              
			                             "emailid1": {
			 				 			    "readonly": false,
			 				                "required": false,
			 				                "type": "string",
			 				                "format": "email",
			                             },
					    "empid": {
					               "type": "string",
					               "required": false,
					               "properties": {}
					           },
				               
	                    }
                    },
                    "options": {
                        "form":{
                            "attributes":{
                                "action":"./lis/lis?func=CreateUser",
                                "method":"post"
                            },
                            "buttons":{
                                "submit":{
                                    "title": "Create New User",
                                    "click": function() {
                                        var val = this.getValue();
                                        if (this.isValid(true)) {
                                            alert("Valid value: " + JSON.stringify(val, null, "  "));
                                            this.ajaxSubmit().done(function(html) {
												//var resp=JSON.parse(html.getValue());
												if(html.status=="Logout")
												{
													window.location=html.redirect;
												}
												alert(html.reason);
												
												
                                            });
                                        } else {
                                            alert("Invalid value: " + JSON.stringify(val, null, "  "));
                                        }
                                    }
                                }
                            }
                        },
                        "helper": "Let us create new LI User",
                        "fields": {
							"username": {
							                "type": "email",
							                "validate": true,
							                "showMessages": true,
							                "label": "Email Address",
							                "helpers": [],
							                "hideInitValidationError": false,
							                "focus": true
							            },
							"password": {
							                "type": "password",
							                "validate": true,
							                "showMessages": true,
							                "label": "Password Address",
							                "helpers": [],
							                "hideInitValidationError": false,
							                "focus": true
							            },		
										"name": {
										                "type": "text",
										                "validate": true,
										                "showMessages": true,
										                "label": "Name",
										                "helpers": [],
										                "hideInitValidationError": false,
										                "focus": true
										            },	
							"address": {
							                "type": "textarea",
							                "label": "Address",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "data": {},
							                "attributes": {},
							                "allowOptionalEmpty": true,
							                "autocomplete": false,
							                "disallowEmptySpaces": false,
							                "disallowOnlyEmptySpaces": false,
							                "rows": 5,
							                "cols": 40,
							                "fields": {}
							            },
							"dob": {
							                "type": "date",
							                "label": "Date of Birth",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "data": {},
							                "attributes": {},
							                "allowOptionalEmpty": true,
							                "autocomplete": false,
							                "disallowEmptySpaces": false,
							                "disallowOnlyEmptySpaces": false,
							                "picker": {
							                    "useCurrent": false,
							                    "format": "YYYY-MM-DD",
							                    "locale": "en_US",
							                    "dayViewHeaderFormat": "MMMM YYYY",
							                    "extraFormats": []
							                },
							                "dateFormat": "YYYY-MM-DD",
							                "manualEntry": false,
							                "readonly": false,
							                "fields": {}
							            },
							"changepassword": {
							                "type": "checkbox",
							                "rightLabel": "Change Password on Next Login",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "fields": {}
							            },
							"multilogin": {
							                "type": "checkbox",
							                "rightLabel": "Allow Multiple Login",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "fields": {}
							            },
							"locked": {
							                "type": "checkbox",
							                "rightLabel": "User is Locked?",
							                "helpers": [],
							                "validate": true,
							                "disabled": false,
							                "showMessages": true,
							                "renderButtons": true,
							                "fields": {}
							            },
							"rights": {"label": "Rights Assigned to User",
			                			"type": "object",
						                "helpers": [],
						                "validate": true,
						                "disabled": false,
						                "showMessages": true,
						                "collapsible": false,
						                "legendStyle": "button",
										"fields" : {
						                     "login": {
	 							                "type": "checkbox",
	 							                "rightLabel": "Login to System",
	 							                "helpers": [],
	 							                "validate": true,
	 							                "disabled": false,
	 							                "showMessages": true,
	 							                "renderButtons": true,
	 							                "fields": {}
						                     },
						                     "administer": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "Administrator",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {}
						                     },
						                     "query": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "Query Location",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {}
						                     },
						                     "monitor": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "Monitor System",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {}
						                     },
						                     "report": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "View Reports",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {}
						                     },
						                     "audit": {
 	 							                "type": "checkbox",
 	 							                "rightLabel": "See Audit Log",
 	 							                "helpers": [],
 	 							                "validate": true,
 	 							                "disabled": false,
 	 							                "showMessages": true,
 	 							                "renderButtons": true,
 	 							                "fields": {}
						                     }
										},
							
							},
							"emailid1": {
							                "type": "email",
							                "validate": true,
							                "showMessages": true,
							                "label": "Secondary Email Address",
							                "helpers": [],
							                "hideInitValidationError": false,
							                "focus": true
							            },
							"empid": {
							                "type": "text",
							                "validate": true,
							                "showMessages": true,
							                "label": "Employee ID",
							                "helpers": [],
							                "hideInitValidationError": false,
							                "focus": true
							            }
                        }
                    },
                    "postRender": function(control) {
                        //control.childrenByPropertyId["name"].getFieldEl().css("background-color", "lightgreen");
                    }
                });
            });
        </script>
   