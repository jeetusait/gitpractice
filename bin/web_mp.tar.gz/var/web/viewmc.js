<div id="form"></div>
<script type="text/javascript">

$.alpaca.Fields.CustomField = $.alpaca.Fields.TextField.extend({
    getFieldType: function() {
        return "checkbox";
    },
    onChange: function(e) {
		if(this.name == "copydata")
		{
		this.getParent().childrenByPropertyId["psiriip"].setValue(this.getParent().childrenByPropertyId["cciriip"].getValue());
		this.getParent().childrenByPropertyId["psirimode"].setValue(this.getParent().childrenByPropertyId["ccirimode"].getValue());
		this.getParent().childrenByPropertyId["psiriusername"].setValue(this.getParent().childrenByPropertyId["cciriusername"].getValue());
		this.getParent().childrenByPropertyId["psiripassword"].setValue(this.getParent().childrenByPropertyId["cciripassword"].getValue());
		this.getParent().childrenByPropertyId["psiriftppath"].setValue(this.getParent().childrenByPropertyId["cciriftppath"].getValue());
		}
		if(this.name == "copydata1")
		{
			this.getParent().childrenByPropertyId["pdiriip"].setValue(this.getParent().childrenByPropertyId["psiriip"].getValue());
			this.getParent().childrenByPropertyId["pdirimode"].setValue(this.getParent().childrenByPropertyId["psirimode"].getValue());
			this.getParent().childrenByPropertyId["pdiriusername"].setValue(this.getParent().childrenByPropertyId["psiriusername"].getValue());
			this.getParent().childrenByPropertyId["pdiripassword"].setValue(this.getParent().childrenByPropertyId["psiripassword"].getValue());
			this.getParent().childrenByPropertyId["pdiriftppath"].setValue(this.getParent().childrenByPropertyId["psiriftppath"].getValue());
		}
    }
});
Alpaca.registerFieldClass("checkbox", Alpaca.Fields.CustomField);

    $(document).ready(function() {
$('#form').alpaca({
    "schema": {
        "type": "object",
        "required": false,
        "properties": {
			"copydata": {
			                "type": "boolean",
			                "required": false,
			                "properties": {}
			            },
						"copydata1": {
						                "type": "boolean",
						                "required": false,
						                "properties": {}
						            },
            "leaname": {
                "readonly": true,
                "required": false,
                "type": "string",
                "properties": {}
            },
            "configname": {
                "readonly": true,
                "required": true,
                "type": "string",
                "minLength": 5,
                "maxLength": 50,
                "properties": {}
            },
	        "fanoutmode": {
	            "readonly": false,
	            "required": true,
	            "disallow": [],
	            "enum": [
	                "fanoutno",
	                "sip",
					"etsi33108"
	            ],
	            "properties": {}
	        },
            "fanoutno": {
                "readonly": false,
                "required": true,
                "type": "string",
                "minLength": 7,
                "maxLength": 100,
                "exclusiveMinimum": false,
                "exclusiveMaximum": false,
                "properties": {}
            },
            "sipaddress": {
                "readonly": false,
                "required": true,
                "type": "string",
                "properties": {}
            },
            "sipport": {
                "readonly": false,
                "required": true,
                "type": "integer",
                "minLength": 4,
                "maxLength": 7,
                "exclusiveMinimum": false,
                "exclusiveMaximum": false,
                "properties": {}
            },
            "fanout33108": {
                "type": "string",
                "required": true,
                "properties": {}
            },
            "cciriip": {
                "type": "string",
                "required": true,
                "properties": {}
            },
            "ccirimode": {
                "readonly": false,
                "required": false,
                "disallow": [],
                "enum": [
                    "FTP",
                    "SFTP"
                ],
                "properties": {}
            },
            "cciriusername": {
                "readonly": false,
                "required": false,
                "type": "string",
                "disallow": [],
                "maxLength": 20,
                "properties": {}
            },
            "cciripassword": {
                "readonly": false,
                "required": false,
                "type": "string",
                "format": "password",
                "disallow": [],
                "maxLength": 50,
                "properties": {}
            },
            "cciriftppath": {
                "readonly": false,
                "required": false,
                "type": "string",
                "disallow": [],
                "maxLength": 50,
                "properties": {}
            },
        "psiriip": {
            "type": "string",
            "required": true,
            "properties": {}
        },
        "psirimode": {
            "readonly": false,
            "required": false,
            "disallow": [],
            "enum": [
                "FTP",
                "SFTP"
            ],
            "properties": {}
        },
        "psiriusername": {
            "readonly": false,
            "required": false,
            "type": "string",
            "disallow": [],
            "maxLength": 20,
            "properties": {}
        },
        "psiripassword": {
            "readonly": false,
            "required": false,
            "type": "string",
            "format": "password",
            "disallow": [],
            "maxLength": 50,
            "properties": {}
        },
        "psiriftppath": {
            "readonly": false,
            "required": false,
            "type": "string",
            "disallow": [],
            "maxLength": 50,
            "properties": {}
        },
        "pdiriip": {
            "type": "string",
            "required": true,
            "properties": {}
        },
        "pdirimode": {
            "readonly": false,
            "required": true,
            "disallow": [],
            "enum": [
                "FTP",
                "SFTP",
				"Stream"
            ],
            "properties": {}
        },
        "pdiriport": {
            "type": "string",
            "required": true,
            "properties": {}
        },
        "pdiritype": {
            "readonly": false,
            "required": true,
            "disallow": [],
            "enum": [
                "By Packet",
                "PCAP",
				"Processed",
				"ProcessedPCAP"
            ],
            "properties": {}
        },
        "pdiriusername": {
            "readonly": false,
            "required": true,
            "type": "string",
            "disallow": [],
            "maxLength": 20,
            "properties": {}
        },
        "pdiripassword": {
            "readonly": false,
            "required": false,
            "type": "string",
            "format": "password",
            "disallow": [],
            "maxLength": 50,
            "properties": {}
        },
        "pdiriftppath": {
            "readonly": false,
            "required": true,
            "type": "string",
            "disallow": [],
            "maxLength": 50,
            "properties": {}
        },
            "iriformat": {
                "readonly": false,
                "required": true,
                "disallow": [],
                "enum": [
                    "ETSI",
                    "Text Only",
                    "XML",
					"TextEtsi"
                ],
                "properties": {}
            }
        },
		"dependencies": {
		            "fanoutno": ["fanoutmode"],
		            "sipaddress": ["fanoutmode"],
		            "sipport": ["fanoutmode"],
		            "fanout33108": ["fanoutmode"],
			"pdiriusername": ["pdirimode"],
			"pdiripassword": ["pdirimode"],
			"pdiriftppath": ["pdirimode"],
			"pdiriport": ["pdirimode"]
		        }
    },
    "options": {
        "focus": false,
        "type": "object",
        "helpers": [],
        "validate": true,
        "disabled": false,
        "showMessages": true,
        "collapsible": false,
        "legendStyle": "button",
        "form":{
            "attributes":{
                "action":"history.go(-1)",
                "method":"post"
			},
            "buttons":{
                "button":{
                    "title": "Go Back",
                    "click": function() {
                    	window.history.go(-1);
                    }
                }
            }
       },
        "fields": {
		    "copydata": {
		                   "label": "Copy Data from CS Profile",
		                   "type": "checkbox",
		                   "helpers": [],
		                   "validate": true,
		                   "disabled": true,
		                   "showMessages": true,
		                   "renderButtons": true,
		                   "rightLabel": "",
		                   "fields": {}
		               },
		   		    "copydata1": {
		   		                   "label": "Copy Data from PS IRI Profile",
		   		                   "type": "checkbox",
		   		                   "helpers": [],
		   		                   "validate": true,
		   		                   "disabled": true,
		   		                   "showMessages": true,
		   		                   "renderButtons": true,
		   		                   "rightLabel": "",
		   		                   "fields": {}
		   		               },
		   		            "fanoutmode": {
		   		                "type": "radio",
		   		                "validate": true,
		   		                "showMessages": true,
		   		                "disabled": false,
		   		                "hidden": false,
		   		                "label": "Voice Fanout Mode",
		   		                "helpers": [],
		   		                "hideInitValidationError": false,
		   		                "focus": true,
		   		                "optionLabels": [
		   		                    "Fanout No",
		   		                    "SIP",
									"ETSI 33.108 Release 14"
		   		                ],
		   		                "removeDefaultNone": false,
		   		                "noneLabel": "None",
		   		                "hideNone": true,
		   		                "useDataSourceAsEnum": true,
		   		                "emptySelectFirst": false,
		   		                "vertical": false,
		   		                "readonly": true,
		   		                "renderButtons": true,
		   		                "fields": {}
		   		            },
            "leaname": {
                "type": "text",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "LEA Name",
                "helpers": [],
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [],
                "name": "leaname",
                "typeahead": {},
                "allowOptionalEmpty": true,
                "data": {},
                "autocomplete": false,
                "disallowEmptySpaces": false,
                "disallowOnlyEmptySpaces": false,
                "renderButtons": true,
                "attributes": {},
                "readonly": true,
                "fields": {}
            },
            "configname": {
                "type": "text",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "Configuration Name",
                "helpers": [],
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [],
                "name": "configname",
                "typeahead": {},
                "allowOptionalEmpty": true,
                "data": {},
                "autocomplete": false,
                "disallowEmptySpaces": true,
                "disallowOnlyEmptySpaces": true,
                "readonly": true,
                "renderButtons": true,
                "attributes": {},
                "fields": {}
            },
            "fanoutno": {
                "type": "text",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "Fanout Number",
                "helpers": [],
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [],
                "name": "fanoutno",
                "typeahead": {},
                "allowOptionalEmpty": true,
                "data": {},
                "autocomplete": false,
                "disallowEmptySpaces": false,
                "disallowOnlyEmptySpaces": false,
                "numericEntry": true,
                "readonly": true,
                "renderButtons": true,
                "attributes": {},
                "fields": {},
				"dependencies": {
				                    "fanoutmode": "fanoutno"
				                }
            },
            "sipaddress": {
                "type": "ipv4",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "SIP Address",
                "helpers": [],
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [],
                "name": "sipaddress",
                "typeahead": {},
                "allowOptionalEmpty": true,
                "data": {},
                "autocomplete": false,
                "disallowEmptySpaces": true,
                "disallowOnlyEmptySpaces": true,
                "renderButtons": true,
                "attributes": {},
                "readonly": true,
                "fields": {},
				"dependencies": {
				                    "fanoutmode": "sip"
				                }
            },
            "sipport": {
                "type": "integer",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "SIP Port",
                "helpers": [],
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [],
                "name": "sipport",
                "typeahead": {},
                "allowOptionalEmpty": true,
                "data": {},
                "autocomplete": false,
                "disallowEmptySpaces": false,
                "disallowOnlyEmptySpaces": false,
                "numericEntry": true,
                "slider": false,
                "renderButtons": true,
                "attributes": {},
                "readonly": true,
                "fields": {},
				"dependencies": {
				                    "fanoutmode": "sip"
				                }
            },
            "fanout33108": {
                "type": "text",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "Fanout Using 33.108 Release 14 Standard",
                "helpers": [],
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [],
                "name": "fanoutip",
                "typeahead": {},
                "allowOptionalEmpty": true,
                "data": {},
                "autocomplete": false,
                "disallowEmptySpaces": false,
                "disallowOnlyEmptySpaces": false,
                "renderButtons": true,
				"readonly" :true,
                "attributes": {},
                "fields": {},
				"dependencies": {
				                    "fanoutmode": "etsi33108"
				                }
            },
	            "cciriip": {
	                "type": "ipv4",
	                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "IP Address for CC IRI",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [],
		                "name": "cciriip",
		                "typeahead": {},
		                "allowOptionalEmpty": true,
		                "data": {},
		                "autocomplete": false,
		                "disallowEmptySpaces": false,
		                "disallowOnlyEmptySpaces": false,
		                "renderButtons": true,
		                "attributes": {},
					"readonly" :true,
		                "fields": {}
		            },
		            "ccirimode": {
		                "type": "radio",
		                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "CC IRI FTP Mode",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [
		                    "FTP",
		                    "SFTP"
		                ],
		                "removeDefaultNone": false,
		                "noneLabel": "None",
		                "hideNone": true,
		                "useDataSourceAsEnum": true,
		                "emptySelectFirst": false,
		                "vertical": false,
		                "readonly": true,
		                "renderButtons": true,
		                "fields": {}
		            },
		            "cciriusername": {
		                "type": "text",
		                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "CC IRI FTP Username",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [],
		                "name": "cciriftpuname",
		                "typeahead": {},
		                "allowOptionalEmpty": true,
		                "data": {},
		                "autocomplete": false,
		                "disallowEmptySpaces": true,
		                "disallowOnlyEmptySpaces": true,
		                "renderButtons": true,
		                "attributes": {},
		                "readonly": true,
		                "fields": {}
		            },
		            "cciripassword": {
		                "type": "text",
		                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "CC IRI FTP Password",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [],
		                "name": "cciriftppass",
		                "typeahead": {},
		                "allowOptionalEmpty": true,
		                "data": {},
		                "autocomplete": false,
		                "disallowEmptySpaces": true,
		                "disallowOnlyEmptySpaces": true,
		                "renderButtons": true,
		                "attributes": {},
		                "readonly": true,
		                "fields": {}
		            },
		            "cciriftppath": {
		                "type": "text",
		                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "CC IRI FTP Path",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [],
		                "name": "cciriftppath",
		                "typeahead": {},
		                "allowOptionalEmpty": true,
		                "data": {},
		                "autocomplete": false,
		                "disallowEmptySpaces": false,
		                "disallowOnlyEmptySpaces": false,
		                "renderButtons": true,
		                "attributes": {},
		                "readonly": true,
		                "fields": {}
		            },
	            "psiriip": {
	                "type": "ipv4",
	                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "IP Address for Packet Data IRI",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [],
		                "name": "psiriip",
		                "typeahead": {},
		                "allowOptionalEmpty": true,
		                "data": {},
		                "autocomplete": false,
		                "disallowEmptySpaces": false,
		                "disallowOnlyEmptySpaces": false,
		                "renderButtons": true,
		                "attributes": {},
					"readonly" :true,
		                "fields": {}
		            },
		            "psirimode": {
		                "type": "radio",
		                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "Packet Data IRI FTP Mode",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [
		                    "FTP",
		                    "SFTP"
		                ],
		                "removeDefaultNone": false,
		                "noneLabel": "None",
		                "hideNone": true,
		                "useDataSourceAsEnum": true,
		                "emptySelectFirst": false,
		                "vertical": false,
		                "readonly": true,
		                "renderButtons": true,
		                "fields": {}
		            },
		            "psiriusername": {
		                "type": "text",
		                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "Packet Data IRI FTP Username",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [],
		                "name": "psiriftpuname",
		                "typeahead": {},
		                "allowOptionalEmpty": true,
		                "data": {},
		                "autocomplete": false,
		                "disallowEmptySpaces": true,
		                "disallowOnlyEmptySpaces": true,
		                "renderButtons": true,
		                "attributes": {},
		                "readonly": true,
		                "fields": {}
		            },
		            "psiripassword": {
		                "type": "text",
		                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "Packet Data IRI FTP Password",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [],
		                "name": "psiriftppass",
		                "typeahead": {},
		                "allowOptionalEmpty": true,
		                "data": {},
		                "autocomplete": false,
		                "disallowEmptySpaces": true,
		                "disallowOnlyEmptySpaces": true,
		                "renderButtons": true,
		                "attributes": {},
		                "readonly": true,
		                "fields": {}
		            },
		            "psiriftppath": {
		                "type": "text",
		                "validate": true,
		                "showMessages": true,
		                "disabled": false,
		                "hidden": false,
		                "label": "Packet Data IRI FTP Path",
		                "helpers": [],
		                "hideInitValidationError": false,
		                "focus": true,
		                "optionLabels": [],
		                "name": "psiriftppath",
		                "typeahead": {},
		                "allowOptionalEmpty": true,
		                "data": {},
		                "autocomplete": false,
		                "disallowEmptySpaces": false,
		                "disallowOnlyEmptySpaces": false,
		                "renderButtons": true,
		                "attributes": {},
		                "readonly": true,
		                "fields": {}
		            },
		            "pdiriip": {
		                "type": "ipv4",
		                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "IP Address for Packet Data CC",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "pdiriip",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": false,
			                "disallowOnlyEmptySpaces": false,
			                "renderButtons": true,
			                "attributes": {},
						"readonly" :true,
			                "fields": {}
			            },
			            "pdiriport": {
			                "type": "integer",
			                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "Transfer Port for Packet Data CC",
				                "helpers": ["Required in case of Stream Transfer"],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "pdiriport",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": false,
				                "renderButtons": true,
				                "attributes": {},
							"readonly" :true,
				                "fields": {},
							"dependencies": {
							                    "pdirimode": ["Stream"]
							                }
				            },
			            "pdirimode": {
			                "type": "radio",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "Packet Data CC FTP Mode",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [
			                    "FTP",
			                    "SFTP",
								"Stream"
			                ],
			                "removeDefaultNone": false,
			                "noneLabel": "None",
			                "hideNone": true,
			                "useDataSourceAsEnum": true,
			                "emptySelectFirst": false,
			                "vertical": false,
			                "readonly": true,
			                "renderButtons": true,
			                "fields": {}
			            },
			            "pdiritype": {
			                "type": "radio",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "Packet Data CC Type",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [
			                    "By Packet",
			                    "PCAP",
								"Processed Data",
								"Processed Data With PCAP"
			                ],
			                "removeDefaultNone": false,
			                "noneLabel": "None",
			                "hideNone": true,
			                "useDataSourceAsEnum": true,
			                "emptySelectFirst": false,
			                "vertical": false,
			                "readonly": true,
			                "renderButtons": true,
			                "fields": {},
							"dependencies": {
							                    "pdirimode": ["FTP","SFTP"]
							                }
			            },
			            "pdiriusername": {
			                "type": "text",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "Packet Data CC FTP Username",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "pdiriftpuname",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": true,
			                "disallowOnlyEmptySpaces": true,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": true,
			                "fields": {},
							"dependencies": {
							                    "pdirimode": ["FTP","SFTP"]
							                }
			            },
			            "pdiripassword": {
			                "type": "text",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "Packet Data CC FTP Password",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "pdiriftppass",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": true,
			                "disallowOnlyEmptySpaces": true,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": true,
			                "fields": {},
							"dependencies": {
							                    "pdirimode": ["FTP","SFTP"]
							                }
			            },
			            "pdiriftppath": {
			                "type": "text",
			                "validate": true,
			                "showMessages": true,
			                "disabled": false,
			                "hidden": false,
			                "label": "Packet Data CC FTP Path",
			                "helpers": [],
			                "hideInitValidationError": false,
			                "focus": true,
			                "optionLabels": [],
			                "name": "pdiriftppath",
			                "typeahead": {},
			                "allowOptionalEmpty": true,
			                "data": {},
			                "autocomplete": false,
			                "disallowEmptySpaces": false,
			                "disallowOnlyEmptySpaces": false,
			                "renderButtons": true,
			                "attributes": {},
			                "readonly": true,
			                "fields": {},
							"dependencies": {
							                    "pdirimode": ["FTP","SFTP"]
							                }
			            },
            "iriformat": {
                "type": "radio",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "IRI Format",
                "helpers": [],
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [
                    "ETSI",
                    "Text",
                    "XML",
					"TextEtsi"
                ],
                "removeDefaultNone": false,
                "noneLabel": "None",
                "hideNone": true,
                "useDataSourceAsEnum": true,
                "emptySelectFirst": false,
                "vertical": false,
                "renderButtons": true,
                "fields": {},
                "readonly": true
            }
        }
    },
    "data": MCDATA,
	"view": {
	        "parent": "bootstrap-edit-horizontal",
	        "wizard": {
	            "title": "Update Monitoring Center",
	            "description": "Update Monitoring Center",
				"hideSubmitButton": true,
	            "bindings": {
	                "leaname": 1,
	                "configname": 1,
					"fanoutmode" : 1,
	                "fanoutno": 1,
	                "sipaddress": 1,
	                "sipport": 1,
	                "fanout33108": 1,
					"iriformat" : 1,
					"cciriip": 2,
					"ccirimode" : 2,
					"cciriusername" : 2,
					"cciripassword" : 2,
					"cciriftppath" : 2,
					"copydata" : 3,
					"psiriip": 3,
					"psirimode" : 3,
					"psiriusername" : 3,
					"psiripassword" : 3,
					"psiriftppath" : 3,
					"copydata1" : 4,
					"pdiriip": 4,
					"pdirimode" : 4,
					"pdiriusername" : 4,
					"pdiripassword" : 4,
					"pdiriftppath" : 4,
					"pdiritype" : 4,
					"pdiriport" : 4
					
	            },
	            "steps": [{
	                "title": "Monitoring Center Info",
	                "description": "Basic and Fanout Information"
	            }, {
	                "title": "Circuit Switched IRI",
	                "description": "Circuit Switched IRI"
	            }, {
	                "title": "Packet Data IRI",
	                "description": "Packet Data IRI"
	            },
				{
				                "title": "Packet Data CC",
				                "description": "Packet Data CC"
				            }],
							
					        
	        }
	    }
});
});
</script>
<div class="text-center p-t-136">
						<a class="txt2" href="#">
							<div class="err" id="add_err"></div>
						</a>
					</div>


