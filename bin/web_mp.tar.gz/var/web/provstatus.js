

<script type="text/javascript">
/*function format ( rowData ) {
	var div = $('<div/>')
		.addClass( 'loading' )
		.text( 'Loading...' );

	$.ajax( {
		url: '/lis/lis?func=GetUserOpt&form=ListLEA',
		data: {
			name: rowData.name
		},
		dataType: 'json',
		type: 'post',
		success: function ( json ) {
			div
				.html( json.html )
				.removeClass( 'loading' );
		} 
	} );

	return div;
} */

function getQueryParams(qs) {
    qs = qs.split('+').join(' ');

    var params = {},
        tokens,
        re = /[?&]?([^=]+)=([^&]*)/g;

    while (tokens = re.exec(qs)) {
        params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
    }

    return params;
}

$(document).ready(function() {
	var query = getQueryParams(document.location.search);
	
	var table = $('#myTable').DataTable( {
		"ajax": "/lis/lis?func=ListStatus&liid="+query.liid,
		"columns": [
			{
				"className":      'details-control',
				"orderable":      false,
				"data":           null,
				"defaultContent": ''
			},
			{ "data": "nename" },
			{ "data": "neid" },
			{ "data": "requeststate" },
			{ "data": "currentstate" },
			{ "data": "requestdate" },
			{ "data": "reqlogs" }
		],
		"order": [[1, 'asc']]
	} );
	
	// Add event listener for opening and closing details
	$('#myTable tbody').on('click', 'td.details-control', function () {
		var tr = $(this).closest('tr');
		var row = table.row( tr );

		if ( row.child.isShown() ) {
			// This row is already open - close it
			row.child.hide();
			tr.removeClass('shown');
		}
		else {
			// Open this row
			row.child( format(row.data()) ).show();
			tr.addClass('shown');
		}
	} );
} );

		</script>
		
		<table id="myTable" class="display" width="75%">
		    <thead>
		        <tr>
		            <th></th>
		            <th>NE Name</th>
		            <th>NE ID</th>
		            <th>Requested State</th>
		            <th>Current State</th>
		            <th>Request Date</th>
		            <th>Request History</th>

					
		        </tr>
		    </thead>
		    
		</table>
		

		
		
		