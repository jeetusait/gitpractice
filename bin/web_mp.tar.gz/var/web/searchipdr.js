
        <div id="form"></div>
        <script type="text/javascript">
            $(document).ready(function() {
                $("#form").alpaca({
                    "data": {
                    },
                    "schema": {
                        "title":"IPDR Query",
                        "description":"",
                        "type":"object",
                        "properties": {
                            "queryname": {
				 			    "readonly": false,
				                "required": true,
				                "type": "string"
							},
                            "tempname": {
				 			    "readonly": false,
				                "required": true,
				                "type": "string"
							},
							"searchfield": {
				                "readonly": false,
				                "required": false,
				                "disallow": [],
				                "enum": [
				                    "IMEI",
				                    "IMSI",
				                    "MSISDN"
				                ],
				                "properties": {}
				            },
				            "imei": {
				                "readonly": false,
				                "required": false,
				                "type": "integer",
				                "disallow": [],
				                "minLength": 14,
				                "maxLength": 15,
				                "exclusiveMinimum": false,
				                "exclusiveMaximum": false,
				                "properties": {}
				            },
				            "msisdn": {
				                "readonly": false,
				                "required": false,
				                "type": "integer",
				                "disallow": [],
				                "minLength": 8,
				                "maxLength": 15,
				                "exclusiveMinimum": false,
				                "exclusiveMaximum": false,
				                "properties": {}
				            },
				            "imsi": {
				                "readonly": false,
				                "required": false,
				                "type": "integer",
				                "disallow": [],
				                "minLength": 15,
				                "maxLength": 15,
				                "exclusiveMinimum": false,
				                "exclusiveMaximum": false,
				                "properties": {}
				            },
				            "srcipaddress": {
				                "readonly": false,
				                "required": false,
				                "type": "string",
				                "disallow": [],
				            },
				            "dstipaddress": {
				                "readonly": false,
				                "required": false,
				                "type": "string",
				                "disallow": [],
				            },
				            "srcport": {
				                "readonly": false,
				                "required": false,
				                "type": "integer",
				                "disallow": [],
				                "minLength": 1,
				                "maxLength": 5
				            },
				            "dstport": {
				                "readonly": false,
				                "required": false,
				                "type": "integer",
				                "disallow": [],
				                "minLength": 1,
				                "maxLength": 5
				            },
				            "startdate": {
				                "type": "string",
				                "required": true,
				                "properties": {}
				            },
				            "enddate": {
				                "type": "string",
				                "required": true,
				                "properties": {}
				            },
				            "warrantno": {
				                "readonly": false,
				                "required": true,
				                "type": "string",
				                "disallow": [],
				                "minLength": 5,
				                "properties": {}
				            },
				            "cellid": {
				                "readonly": false,
				                "required": false,
				                "type": "text",
				                "disallow": [],
				                "minLength": 5,
                				"pattern":"[0-9]-[0-9]-[0-9]-[0-9]",
				                "properties": {}
				            },
				               
	                    },
						"dependencies": {
						            "imei": ["searchfield"],
						            "msisdn": ["searchfield"],
							"imsi": ["searchfield"]}
                    },
                    "options": {
                        "form":{
                            "attributes":{
                                "action":"./lis/lis?func=searchIPDR",
                                "method":"post"
                            },
                            "buttons":{
                                "submit":{
                                    "title": "Search IPDR",
                                    "click": function() {
                                        var val = this.getValue();
                                        if (this.isValid(true)) {
                                            alert("Valid value: " + JSON.stringify(val, null, "  "));
                                            this.ajaxSubmit().done(function(html) {
												//var resp=JSON.parse(html.getValue());
												if(html.status=="Logout")
												{
													window.location=html.redirect;
												}
												alert(html.reason);
                                            });
                                        } else {
                                            alert("Invalid value: " + JSON.stringify(val, null, "  "));
                                        }
                                    }
                                }
                            }
                        },
                        "helper": "Search IPDRs",
                        "fields": {
				            "queryname": {
				                "type": "text",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "Request Name",
				                "helpers": [],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "queryname",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": true,
				                "readonly": false,
				                "renderButtons": true,
				                "attributes": {},
				                "fields": {},
				            },
				            "tempname": {
								"type": "select",
				                "label": "Template Name",
				                "helpers": [],
				                "helpersPosition": "right",
				                "validate": true,
				                "disabled": false,
				                "showMessages": true,
				                "renderButtons": true,
				                "useDataSourceAsEnum": true,
				                "multiselect": {
				                    "disableIfEmpty": true
				                },
				                "noneLabel": "None",
				                "hideNone": true,
							    "dataSource": "/lis/lis?func=gettemplatelist",
								
				            },
							"searchfield": {
							                "type": "radio",
							                "validate": true,
							                "showMessages": false,
							                "disabled": false,
							                "hidden": false,
							                "label": "Search on IMSI/MSISDN/IMEI",
							                "helpers": [],
							                "hideInitValidationError": false,
							                "focus": true,
							                "optionLabels": [
							                    "IMEI",
							                    "IMSI",
							                    "MSISDN"
							                ],
							                "removeDefaultNone": true,
							                "noneLabel": "None",
							                "hideNone": true,
							                "useDataSourceAsEnum": true,
							                "emptySelectFirst": false,
							                "vertical": false,
							                "readonly": false,
							                "renderButtons": true,
							                "fields": {}
							            },
				            "msisdn": {
				                "type": "integer",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "MSISDN/ISDN",
				                "helpers": [],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "msisdn",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": true,
				                "disallowOnlyEmptySpaces": true,
				                "numericEntry": true,
				                "slider": false,
				                "renderButtons": true,
				                "attributes": {},
				                "readonly": false,
				                "fields": {},
								"dependencies": {
								                    "searchfield": "MSISDN"
								                }
				            },
				            "imsi": {
				                "type": "integer",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "IMSI",
				                "helpers": [],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "imsi",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": false,
				                "numericEntry": false,
				                "slider": false,
				                "renderButtons": true,
				                "attributes": {},
				                "readonly": false,
				                "fields": {},
								"dependencies": {
								                    "searchfield": "IMSI"
								                }
				            },
				            "imei": {
				                "type": "integer",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "IMEI",
				                "helpers": [],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "imei",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": true,
				                "disallowOnlyEmptySpaces": true,
				                "numericEntry": true,
				                "slider": false,
				                "renderButtons": true,
				                "attributes": {},
				                "readonly": false,
				                "fields": {},
								"dependencies": {
								                    "searchfield": "IMEI"
								                }
				            },
				            "srcipaddress": {
				                "type": "ipv4",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "Source IP Address",
				                "helpers": [],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "srcipaddress",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": false,
				                "renderButtons": true,
				                "attributes": {},
				                "readonly": false,
				                "fields": {}
				            },
				            "dstipaddress": {
				                "type": "ipv4",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "Destination IP Address",
				                "helpers": [],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "dstipaddress",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": false,
				                "renderButtons": true,
				                "attributes": {},
				                "readonly": false,
				                "fields": {}
				            },
				            "srcport": {
				                "type": "integer",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "Source Port",
				                "helpers": [],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "srcport",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": false,
				                "numericEntry": false,
				                "slider": false,
				                "renderButtons": true,
				                "attributes": {},
				                "readonly": false,
				                "fields": {},
				            },
				            "dstport": {
				                "type": "integer",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "Destination Port",
				                "helpers": [],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "dstport",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": false,
				                "numericEntry": false,
				                "slider": false,
				                "renderButtons": true,
				                "attributes": {},
				                "readonly": false,
				                "fields": {},
				            },
				            "startdate": {
								"type": "datetime",
				                "label": "Start Date",
				                "helpers": [],
				                "validate": true,
				                "disabled": false,
				                "showMessages": true,
				                "renderButtons": true,
				                "data": {},
				                "attributes": {},
				                "allowOptionalEmpty": true,
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": false,
				                "picker": {
				                    "useCurrent": true,
				                    "format": "YYYY-MM-DD HH:mm:ss",
				                    "locale": "en_US",
				                    "dayViewHeaderFormat": "MMMM YYYY",
				                    "extraFormats": [
				                        "MM/DD/YYYY hh:mm:ss a",
				                        "MM/DD/YYYY HH:mm",
				                        "MM/DD/YYYY"
				                    ]
				                },
				                "dateFormat": "YYYY-MM-DD HH:mm:ss",
				                "manualEntry": true,
				                "fields": {}
				            },
				            "enddate": {
								"type": "datetime",
				                "label": "End Date",
				                "helpers": [],
				                "validate": true,
				                "disabled": false,
				                "showMessages": true,
				                "renderButtons": true,
				                "data": {},
				                "attributes": {},
				                "allowOptionalEmpty": true,
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": false,
				                "picker": {
				                    "useCurrent": false,
				                    "format": "YYYY-MM-DD HH:mm:ss",
				                    "locale": "en_US",
				                    "dayViewHeaderFormat": "MMMM YYYY",
				                    "extraFormats": [
				                        "MM/DD/YYYY hh:mm:ss a",
				                        "MM/DD/YYYY HH:mm",
				                        "MM/DD/YYYY"
				                    ]
				                },
				                "dateFormat": "YYYY-MM-DD HH:mm:ss",
				                "manualEntry": true,
				                "fields": {},
				            },
				            "warrantno": {
				                "type": "text",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "Request Reference Details",
				                "helpers": [],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "warrantno",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": false,
				                "disallowOnlyEmptySpaces": false,
				                "readonly": false,
				                "renderButtons": true,
				                "attributes": {},
				                "fields": {}
				            },
				            "cellid": {
				                "type": "text",
				                "validate": true,
				                "showMessages": true,
				                "disabled": false,
				                "hidden": false,
				                "label": "Cell ID",
				                "helpers": ["Cell ID should be in format 999-99-99999-99999"],
				                "hideInitValidationError": false,
				                "focus": true,
				                "optionLabels": [],
				                "name": "cellid",
				                "typeahead": {},
				                "allowOptionalEmpty": true,
				                "data": {},
				                "autocomplete": false,
				                "disallowEmptySpaces": true,
				                "disallowOnlyEmptySpaces": true,
				                "readonly": false,
				                "renderButtons": true,
				                "attributes": {},
				                "fields": {}
				            }
                        }
                    },
                    "postRender": function(control) {
                        //control.childrenByPropertyId["name"].getFieldEl().css("background-color", "lightgreen");
                    }
                });
            });
        </script>
   