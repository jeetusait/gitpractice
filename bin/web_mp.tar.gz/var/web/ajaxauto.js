<script type="text/javascript">
var interval = 3000;  // 1000 = 1 second, 3000 = 3 seconds
function doAjax() {
    $("#add_err").css('display', 'inline', 'important');
     $("#add_err").html("Checking Status ...");
    $.ajax({
            type: 'GET',
            url: '/lis/lis?func=getstatus&seqid=SEQID',
			
		success: function (data) {
				var resp=JSON.parse(data);
				if(resp.status=='2') 
				{
					window.location='/lis/lis?func=ViewREPORT&seqid=SEQID';
				}
				if(resp.status=='1')
				{
				    $("#add_err").css('display', 'inline', 'important');
				     $("#add_err").html("Current Status ..."+resp.status);
				 	setTimeout(doAjax, interval);
				}
				if(resp.status=='3')
				{
					alert('Report Failed with Error'+resp.error);
				}
                    // first set the value     
            }
    });
}
setTimeout(doAjax, interval);
</script>
						<a class="txt2" href="#">
							<div class="err" id="add_err"></div>
						</a>

<Div class="button"><A Href='http://localhost:8080/lis/lis?func=GenReport'>Back</A></div>

