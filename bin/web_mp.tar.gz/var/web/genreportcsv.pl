#!/usr/bin/perl

use IO::File;
use DBI();
use Try::Tiny;
use strict;

my $config=do("/var/web/config.pl");

my $oradb=$config->{"mysqldb"};
my $oradb_user=$config->{"mysql_user"};
my $oradb_passwd=$config->{"mysql_passwd"};

my $mysqldb=$oradb;
my $mysql_user=$oradb_user;
my $mysql_passwd=$oradb_passwd;
my $workarea="/var/web/reportdata/";

my $dbh = DBI->connect($mysqldb, $mysql_user, $mysql_passwd, {'RaiseError' => 1});

my $seqid = $ARGV[0];
my $rowcount=0;

try
{
	my $sth=$dbh->prepare("select * from reportqueue where seqid = $seqid");
	$sth->execute();
	
	my $checktitle='';

	if(my $row=$sth->fetchrow_hashref())
	{
		my $query=$row->{"reportquery"};

		print $query;
	
		try
		{
			$sth=$dbh->prepare("drop table reportuser.report$seqid");
			$sth->execute();
		}
		catch
		{
			print $_;
		};
		try
		{
			print "create table reportuser.report$seqid as ".$query."\n";
			
			
			$sth=$dbh->prepare("create table reportuser.report$seqid as ".$query);
			$sth->execute();
		}
		catch
		{
			print $_;
		};
		
	    my $sth3=$dbh->prepare("select count(1) count from reportuser.report$seqid");
		$sth3->execute();
		my $row9=$sth3->fetchrow_hashref();
		if($row9->{"count"}==0)
		{
		       die "Report generated with no rows";
		}
		
		my $sth1=$dbh->prepare("select * from reportuser.report$seqid");
		$sth1->execute();
		
		my @titles= split(/,/,join (",", @{$sth1->{NAME}}));
		my $breakfield='';
		
		foreach my $title (@titles)
		{
			
			my $sth2=$dbh->prepare("select * from reportcustomizations where COLUMNNAME = '".$title."' and lookup is not null");
			$sth2->execute();
			if(my $row5=$sth2->fetchrow_hashref())
			{
				my $sth3=$dbh->prepare("update reportuser.report$seqid set $title = $title || '-' || (select showvalue from (".$row5->{"lookup"}.") where refvalue = $title and rownum = 1)");
				$sth3->execute();
			}
			
		}

		my $sth4=$dbh->prepare("select * from reportcustomizations where reportid = '".$row->{"reportid"}."' and orderby is not null");
		$sth4->execute();
		my $orderby="";
		
		if(my $row10=$sth4->fetchrow_hashref())
		{
			$orderby=$row10->{"orderby"};
		}

		$sth4=$dbh->prepare("select * from reportcustomizations where reportid = '".$row->{"reportid"}."' and changesheet = 1");
		$sth4->execute();
		if(my $row9=$sth4->fetchrow_hashref())
		{
			if($orderby eq '')
			{
			 	$sth1=$dbh->prepare("select * from reportuser.report$seqid order by ".$row9->{"columnname"});
			}
			else
			{
				$sth1=$dbh->prepare("select * from reportuser.report$seqid order by ".$row9->{"columnname"}.", $orderby");
			}
                $sth1->execute();
		}
		else
		{	
			
			if($orderby eq '')
			{
				$sth1=$dbh->prepare("select * from reportuser.report$seqid");
			}
			else
			{
				$sth1=$dbh->prepare("select * from reportuser.report$seqid order by $orderby");
			}
			$sth1->execute();
		}
	
		my $fh=IO::File->new(">>$workarea/$seqid.csv");
	
		foreach my $title (@titles)
		{
			print $fh $title."~";

			
		}
		print $fh "\n";
	
		while(my $row2=$sth1->fetchrow_hashref())
		{
			foreach my $title(@titles)
			{
				if(defined($row2->{$title}))
				{
					print $fh $row2->{$title}."~";
				}
				else
				{
					print $fh '~';
				}
			}
			print $fh "\n";
			$rowcount+=1;
		}
		
		`/var/web/csvtopdf.pl $workarea/$seqid.csv $seqid`;
	
		$sth=$dbh->prepare("update reportqueue set generatedate = now(), rowcount='$rowcount', filepath = '$workarea/$seqid.csv', reportstatus = 2 where seqid = $seqid");
		$sth->execute();
	}
}
catch
{
	my $comment=$dbh->quote($_);
	my $sth=$dbh->prepare("update reportqueue set generatedate = now(), reportstatus = 3, reportcomment = $comment where seqid = $seqid");
	$sth->execute();
};
