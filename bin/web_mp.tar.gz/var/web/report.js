<script type="text/javascript">


$(document).ready(function() {
	var table = $('#myTable').DataTable( {
		"ajax": "AJAXSTR",
		"columns": [
			FIELDLIST
		],
		scrollY: true,
        scrollX: true,
        scrollCollapse: true,
		scroller: true,
        paging: true,
		dom: 'Bfrtip',
		colReorder: true, responsive: true,
		select:true,
		lengthMenu: [
		            [ 10, 25, 50, -1 ],
		            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
		        ],
        buttons: [
            'colvis','copy', 'csv', {
                extend: 'pdfHtml5',
                orientation: 'landscape',
                pageSize: 'LEGAL',
                title: 'FILENAME',
				exportOptions: {
				                    columns: ':visible'
				                },
                messageTop: 'REPORTTITLE', messageBottom: null
            }, {
                extend: 'excelHtml5',
                title: 'FILENAME',
				exportOptions: {
				                    columns: ':visible'
				                },
                messageTop: 'REPORTTITLE'
							}, 'pageLength'
        ],
	} );
} );

	
	// Add event listener for opening and closing details
	

		</script>
		
		<table id="myTable" class="display compact" width="100%">
		    <thead>
		        <tr>
		            TITLELIST
		        </tr>
		    </thead>
		    
		</table>
		

		
		
		