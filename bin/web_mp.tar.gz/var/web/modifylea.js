        <div id="form"></div>
        <script type="text/javascript">
$('#form').alpaca({
    "schema": {
                        "title":"Modify LEA",
                        "description":"",
        "type": "object",
        "required": false,
        "properties": {
            "leaname": {
                "type": "string",
                "required": false,
                "properties": {}
            }
        }
    },
    "options": {
        "form":{
            "attributes":{
                "action":"./lis/lis?func=UpdateLEA&leaid=LEAID",
                "method":"post"
            },
            "buttons":{
                "button":{
                    "title": "Go Back",
                    "click": function() {
                    	window.history.go(-1);
                    }
                },
                "submit":{
                    "title": "Modify LEA",
                    "click": function() {
                        var val = this.getValue();
						
                        if (this.isValid(true)) {
                            //alert("Valid value: " + JSON.stringify(val, null, "  "));
                            this.ajaxSubmit().done(function(html) {
								//var resp=JSON.parse(html.getValue());
								if(html.status=="Logout")
								{
									alert(html.reason);
									window.location=html.redirect;
								}
								else if(html.status=="Failed")
								{
									alert("LEA not Updated : "+html.reason);
								}
								else
								{
									alert(html.reason);
								}
                            });
                        } else {
                            alert("Invalid value: " + JSON.stringify(val, null, "  "));
                        }
                    }
                }
            }
		},
        "focus": false,
        "type": "object",
        "helpers": [],
        "validate": true,
        "disabled": false,
        "showMessages": true,
        "collapsible": false,
        "legendStyle": "button",
        "fields": {
            "leaname": {
                "type": "text",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "Law Enforcement Agency Name",
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [],
                "name": "leaname",
                "typeahead": {},
                "allowOptionalEmpty": false,
                "data": {},
                "autocomplete": false,
                "disallowEmptySpaces": true,
                "disallowOnlyEmptySpaces": true,
                "fields": {},
                "renderButtons": true,
                "attributes": {}
            }
        }
    },
    "data": LEADATA
});
</script>