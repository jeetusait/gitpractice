 <div id="form"></div>
        <script type="text/javascript">
$('#form').alpaca({
    "schema": {
                        "title":"Show Location",
                        "description":"",
        "type": "object",
        "required": false,
        "properties": {
            "mobileno": {
                "type": "string",
                "required": false,
                "properties": {}
            }
        }
    },
    "options": {
        "form":{
            "attributes":{
                "action":"/lis/lis?func=showlocation",
                "method":"post"
            },
            "buttons":{
	            "submit":{
	                "title": "Show Location",
	            }
            }
		},
        "focus": false,
        "type": "object",
        "helpers": [],
        "validate": true,
        "disabled": false,
        "showMessages": true,
        "collapsible": false,
        "legendStyle": "button",
        "fields": {
            "mobileno": {
                "type": "text",
                "validate": true,
                "showMessages": true,
                "disabled": false,
                "hidden": false,
                "label": "Target Number",
                "helpers": [
                    "Enter Number to Search prefix with 91 for Indian Number"
                ],
                "hideInitValidationError": false,
                "focus": true,
                "optionLabels": [],
                "name": "mobileno",
                "typeahead": {},
                "allowOptionalEmpty": false,
                "data": {},
                "autocomplete": false,
                "disallowEmptySpaces": true,
                "disallowOnlyEmptySpaces": true,
                "fields": {},
                "renderButtons": true,
                "attributes": {}
            }
        }
    },
    "data": {}
});
</script>

<div class="text-center p-t-136">
							<div id="add_err">

</div>
					</div>
