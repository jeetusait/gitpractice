<div class="button">
PDFPLACE
<A href="/reportdata/IPDRSEQID.csv.xlsx" download="FILENAME">Download XLS File</A>

</div>
<br>
REPORTTITLE<br>
REPORTCOMMENTS<br>
<script type="text/javascript">

$(document).ready(function() {


function getBase64FromImageUrl(url) {
    var img = new Image();
		img.crossOrigin = "anonymous";
    img.onload = function () {
        var canvas = document.createElement("canvas");
        canvas.width =this.width;
        canvas.height =this.height;
        var ctx = canvas.getContext("2d");
        ctx.drawImage(this, 0, 0);
        var dataURL = canvas.toDataURL("image/png");
        return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
    };
    img.src = url;
}
	
	
       var dTable =  $('#myTable').DataTable( {
         "processing": true,
         "serverSide": true,
		"paging": true,
		"autoWidth": true,
	searching: false,
		   "scrollX": true,
"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
	dom: 'Bfrtip',
buttons: [
           'colvis', 'copy', 'csv', 'excel', 'pageLength', {extend : 'pdfHtml5', text: 'Generate PDF',
		   filename: 'FILENAME',
		exportOptions: {
			columns: ':visible',
			search: 'applied',
			order: 'applied'
		},
		customize: function (doc) {
			//Remove the title created by datatTables
			doc.content.splice(0,1,{
          text: [{
            text: 'Extracted by - USERNAME \n',
            bold: true,
            fontSize: 16
          }, {
            text: ' Report Params - PARAMS\n',
            bold: true,
            fontSize: 11
          }],
          margin: [0, 0, 0, 12],
          alignment: 'left'
        });
			//Create a date string that we use in the footer. Format is dd-mm-yyyy
			var now = new Date();
			var jsDate = now.getDate()+'-'+(now.getMonth()+1)+'-'+now.getFullYear();
			var logo = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCABHAJIDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/KKKQuB3oAWijdTTIo/iX86AHUU3zV/vL+dOzmgCKT7grivGn7QHg74fX7Wura9p9reKAWtg/mTID03IuSv44rrriORl2q21mBAb0PbivgPRPgBrH7MvgrxhqHjG31bxR4ykNxLpOpwWX2u3ady5W6cvuVpiSp+cfL0A4zXp5XgaOIbjVnZq1kt227fJLr5HzufZriMFTU6NO973b2SSv01beyPsLT/2nPBOqBZP7aW1hbpPdW8tvB/38dQn5mu7tbqO8hWSNlkVwGVgchgeQQfSvyW0Pxj8afir/wASkx+OPFEMh3taSW8vklz/AHyQE289GIUV+gn7Bnwl8TfA39nXSfD/AIuvUm1aOa4uBbJL5kemQySF47VX/iEYOOOBkgcAV6ufZDSy+nGSqxlJu3Knd277I8jhXirEZtVlCdGUYxV+Zqyv2PcKKh+2J/ej/wC+qPtif3o/++q+XPu+Vk1FRrcq3RlP0NIbyNf4l/76oDlZLRTVlV/usDTqCQooooAKKKKAPz5/bZ/4Le6L8G9Z1vwj8P8ASZtc8VaTczafdXt/G0NjYXETmNwF4eYqwI42rkfeIr4M1D/gqj+0DfXs0zfEvU186Rn2RWdsqJk5wo8vgDsK+g/+Cgn/AAS5/wCFM/Dr4tfGDXPEjX2o6hr02oaZp1pFshtorvUMjznb5ncJKeFCgHu2K/P2v7U8JeE+E8dlftqFFVZqynKav71k2ldaJXtpo/M/lHjziLiChj/ZYipKmrXjGLsrXsm7Pd26n69f8EWv2mfH37RXgn4j3HjbxRfeIZtHntls3uUjUwB4pCwGxV6kDrX5yfFz/grN+0RofxU8UafafEzUobOx1i8t4I/sVniONJ3VVyYc8AAc19w/8G97Y+Hnxa/6+LP/ANEy1+SfxzOPjV4y/wCw9f8A/pTJX8T/AEiP+E3iCtQwH7uCktI6L4YvZWW5/pz9AzIcv4hwtZ53RjXahFpzSlZ3krq9+iSPdbD/AIKz/tO3sDTQfETXriGM4Z10q0ZAfQnyMV1/w9/4L1ftCeDbyM3+taL4kgjbLx3+nCMkdxvh8sg+/NfaX/BuNoNnq37KPir7RbwTf8VFOpDxhv8AljBWb/wXf/4J9eGLr4F3XxW8M6Tb6V4h8OSx/wBpG1hCrqNs7rGxkVQAWj3KwfGdoYEkYx+Y08vzNYCOYUcRJvl5nFt7derv9x+y4ri/gWtxjU4RzDJaUIe09nGpFJavRNpJNXdlo3Y9f/4Jxf8ABZXwn+2xq48MaxZjwn438svFZSzeZb6gFGWMEpAJI5JRgGAyRuAJHmf/AAXl/bQ+J37KGs/DdPh34suvDMeuJfPeCGCGX7QY/I2Z8xGxje3THWvxy8H+LtS8AeKNN1zR7qax1TSbqO8spozhoZo23Kw/Efj0r76/4Lh/GFPj38H/ANnfxfGu1de0W8vdn/PMulmxX8GJH4VNLiivisorNytVhb3lpdNpdOvcrMPAnKuH/ETLY0oKpg8Q5JwklJRai3bW9091fXRmZ+wD/wAFRvj58Wv2x/AHh3xJ8RtS1TQ9Y1Bor6zeztVW4j8mRtpKRBhyB0I6Vy37b/8AwUX+OHgD9rz4i6Lo3xI1/T9K03XJ4LS1j2eXbxLwqKCvQCvKf+CX3/J/fwv/AOwo/wD6TS1kf8FEPl/bg+KX/YxXP9K8d5tjHk6qurLm57Xu72tte+x+p0vD3hun4lPAQwVNUvq6lycseXm5rXta17aXsbI/4Kg/tCv934oeJD9FhP8A7JSP/wAFQ/2hYjhvih4kH1WMf+yV9w/8G1fhzT/EHh/4qLfWVvd+XdWIQyxq23McmcZFeB/8HAmi2mgft1Q29lDFbw/8I9bNsiQIufOuOcCtK2Hx1LKo5l9Yn7z+G77tb38ux5mV5zwrjOP63Bf9jUoqmm+fli72Sfw8um9t+h6T/wAEbP26vi18bP2yBonjDx1rGv6MugXdwbS52+X5qNFsbAUcjcfzr5v+Of8AwUY+OWg/GvxhY2vxQ8VQ2djr1/bW8STjbFGlzIqqOOgAA/Cu1/4IMN/xnjz/ANCxff8Ao2GvmH9oo4/aB8ef9jLqX/pXJWOIzLF/2RSq+0lfnlrd32Xmd2ScB8Pz8RsfgZ4Sn7KNGm1HlVk25XaVrJvuj9oP+CBfx88aftAfs9eKtR8beI9T8SXtnrz28M97JueKMQQtsHtuZj+Nfe27Py96/Lf/AINqfiVpcvwu8d+EftSrrlvqqamYG4Z7eWKONXX1AeJgfTK+or9SfvLX6lw7WdXL6c5S5nbV7n8G+MmVwy/jDHYWlTVOCn7sUrJRaTVktLNdiWigdKK9w/MQooooA+Sf+C1H/KPjxp/11sf/AErir8Ph/q1r9v8A/gtScf8ABPrxj/tT2I/8m4a/EFvuL9K/tP6N/wDyI6/+N/8ApMT+WPGiX/CvT/wr8z9PP+DfRsfDv4t/9fNp/wCiZK/JX45/8lp8Zf8AYev/AP0pkr9Tv+Dey5lM/wAYYfMbyfsmnSCPPyhiLoE49cAD8K/LH48f8lv8Zf8AYev/AP0pkr+K/pRU+XiWsv7y/GMT/UX9nDU5sHif+vcfzkfsF/wbanP7J/ij/sZJ+f8Atjb179/wWB1KDSv+Cd3xOa4ZVVtLaJdxxl3IRAPcsRXxL/wQ6/bj+Fv7L37NXiLTfHHjHS9Av7jW5bmK3nYmR4jFCoYAA5BKsPwrJ/4Ksf8ABQ+9/b98JQ/Dv4KeG/F3ijwutylxq2qWmkXLJdtEcxwogTdtD4dmcDJVAAQSa+MweLgslUKdpTcGlFau7VtlqGdcI5hX8Up4itTdOjGupuc1yxUYyTb5nZO9rKz1Z+YrDPTp1r7C/wCCgtnLp37DP7KsNwpEjeHr2XnqEf7Kyf8AjrLXmnwC/wCCdnxW+Nnxg0PwtN4L8UaDb6pdLHeajf6bLbwWFuDmWVmdQOEBwOpOAOtfX/8AwcSeA7P4ZeH/AIGaJp0It9M0vT9QsrcKPlCotogXPrtUV8Pg8lxlDLsRVrU3HRJXVr6pv7j+rOMPEDJsbxtkmV4KvCo4zlKTjJNL3HFXa7tvTyPkL/gl6f8AjP74Xf8AYUf/ANJpqyf+Chjf8Zv/ABS/7GK5/nWv/wAEv/k/b7+F3/YVk/8ASaWsv/goj/yfB8Uf+xguf/Za81/8iRX/AOfn6H1fMn4rOS/6BV/6UVf2Yv25fiV+xzbatB4B16PR11yRJbvdaRzGVowVXBkVsYBPT1rn/wBon9pTxf8AtVfEFfFHjjVI9W1pbaO0EywLDiJSzKNqqF6u3OM81+hX/Buf8HvDXxT8PfE5vEOhaXrP2W6svJ+2Wkc3lhkkyFLKcZwM49K8N/4LweAtH+G/7bsOn6Fplnpdj/wj9u/kWkCQx7jNcAnaoAzgDnHYV2YrLcTDJYYmVZuDekNbLV+dvwPmMl44yKt4nV8lp5dCOKinetpzS92Ls9L6ppb9Bv8AwQYTf+3g3/Ys33/oyGvl/wDaHx/w0B48/wCxk1L/ANKpK+o/+CBwVv2913f6v/hG77d/33BXln7QEvwVPxw8aedbfFQXX9vX32gx3Nh5Zk+0yb9u5Cdu7OMnOMUvq/tcmpXkl78t/RHRQzeWX+J2YTVGVS9GlpFJ21lvdo5n9h/9qTUv2Pv2k/DvjaxaRre0m+z6pAhz9rs5CFlXHqBhl/2kWv25sf8Agtp+zhJaIz/EKFX25ZTYXHHt/q6/ESwX4L3t1HbxWPxcmmkIWOOKewZ3PoAEya9Bsf2VdB1OyW4h+GP7Sslu33ZRpcO0/Q+TXs8O1szwtJ0cJFTi3fXmdvS1j898XuGeEeJcwjj82jVw9WK5bp048yvdc3M3e2trW3P1/wD+H2f7N2OPiBD/AOAFz/8AG6dH/wAFsP2by+D8QoAvr/Z9z/8AG6/HjXv2YvDPhrT/ALVffDX9pC1tRnM0mmQiNfq3k4FcLC/wPju9txa/FxVVsOq3Onh1Pofkr3qmf5pRmliKcY+vMj8rpeCXB+Koynga1eo0m9HTf5XP6Z4tShljVlb5WAIoqvosqf2Nabfu+SmP++RRX3qWh/I8qaUmj5z/AOCsnhCz8b/sQeKrHUNf0vwxazT2bPqGorK1tFtuYyAwiR3+Y4Awp5IzX5Dj9mnwm23/AIvf8Nf+/Wo//GK/cT9rH9mjT/2s/gbq3gXVNQvtLstXaFnuLTaZo/KlWUbQwK8lQOR0r5BP/BvR4FVv+R88YH/gFt/8RX7b4a8cYPJsvnh8RiqlGTk2lCMWrNJXu4yd9O/Q/FePeEcZmeOjWw9GM4qKV5Np3ve1k13M7/ghx8KtH8B6v8To9J8eeGPGX9oWunK40mO5Q2YH2nBk86JB824425+4c44rxL4hf8G5/wAQPGHj3XNYXx34bjXVtRub1IxZTEoJZWcA/N1Aavvr9hT/AIJyaD+whqHia40XxBrGtt4njto5xfrEvkiAylduxR1805z6CvpAfd6Yr8n8Ro4HP82qYqc5VYu1pSVm9EndJJdLbdLn7n4N8ZcQcC4HkyqSo1JK0lZSVk21Zu/c/B/4wfsoeCf+CZuo2uj61b6T8Ufi5eR/bSL6Bzofhu3JIic22Qbm4faSFlPlqBkqeM63wB+En7Qn/BRq+ul0vxRqEfh/S5Bb3E8982n6TZORkRRW8AClgpB2pHgArkjIr6k/4LFf8E5PFvxc8eL8UPAtjNr119ijtNW0mE/6Q4jyEmgX+P5TtZB83yggHmvln9iD/go14r/4J93mqeHLjw7Hqmh3159rutKvS9je2txtVGeNmUkblRQVdSPlGCOc/u3A2Q5XheEoz4XpU547Tm5+VyWutuby2u0mtdT8Y8SvETifPuJ5VeKMVU+r3duVtK3TRaJd7HrWuf8ABBn4saJpkl3pvjrw9fXyqSsRN1btKeuPM5xz3Ir5w8W/FX4w/su+MNS8C+Kr68uFsHC33h7xGqaxpdyjDKnypt6MjLyGjIOOhBr7X8Q/8HDuljR5P7K+G+qSagy/ILzUoo4FbHcqpYjPsPwr4N+LPxM8c/t1/Hu911tLuNc8Sa00ccVjo9m8q28SDbHEijJ2qDyzHk5JPNfWcH4POcVOpT4woUlhuV6yUE76fy6Wte7flqfBZ9muGwdSliOGcRU9upLZy++71vfsz6W/4J1fsdeCf2oPj34Z+Kfw9aHwDqvgTUfN8U+EpGkurNxJHII57CRiXjjf5gY5CwQrgHGM9Z+05/wb8+LPjl+0F4u8ZWvxA0fT7fxJqcl/DbtpkkjQq5yFZg4BI9RX0V/wSL/YF1v9kbwTrWveLvLh8VeLfJWSxjcSDTLaLcyRsw4MjM5ZsZAwoyeTX2gGyowK/lPjnhvIHmlfD5ZG+H57xte17JOz7Xul3R/X/AfjNxvhKNHMsViH9ZjT5HKSUny3uk7p6nxz/wAEof8AgmzrX/BPLTvGUGreJLHxD/wks1vJGbe0a3EQiV1IbcTnO7t6V5v/AMFMP+CNviL9uf8AaNh8aaX4w0/RLVdLhsDbzWDTybo3lYtuVgMHzBx7V+hw+YUHnrXztTJsLPCrByj7i2V3673uelhPEzP8Pn0uJaVVLFTVnKy1uktrW2S6H5y/8E5/+CKviT9iv9oweN9T8aaXrlr/AGVc6d9mg094ZMymMhtzMRgbD+deW/G7/ggDp2i+JPF3xD8XfFhdM8KreXmu6mlvouJ4bZpHmkRHMpG/adoJU8447V+tp5P161xf7QHwjsfj58GvEng/UJJIbPxFYS2LyRjLxb1wHA7lWwce1LB8N5Y3SoV4P2Sld2buk2rta66dDuxnjXxlHFV82w+JtiKkFFysldK7S20s3utT8KR+0fceEb0eH/gloS/DvSbyZbS2ksYxceItYLMFQ3F6wMu9yR+7hKICcAHrX0X4P/4Ir/HT4xaMuqeLPGllpN5eKHa31G/utSukzziQglQwz0DHFfPnx1/ZL+J37DHxLhutZ0m8hXRb6O80zXrWEzafcNE4eOQPghTkAlJMEdMd6+u/hV/wcGNp/hmCHxZ4Ba71OFQHu9Jv1WGcj+Ly5FJTPpuNf2Hm+W1MHluHXAlGnKk170koOd+nxfj1ufxrHinG5pmVatxliavtG+spW89r/LY8R/aF/wCCdfx1/YY8OzeLNP8AE15eaFYbWutR0DU7m3lslzgPJESrBBxkruAzzgV5dpPx38P/AB81S30f446XB4isbphbjxdYwJa+ItD3fKJjMihbuNeC0c6uSAcNng+6/tr/APBaHWv2mPhlqXg7QfDkHhXQ9Yj+z6hdXV0Lq7uISfmjTChIw3Qn5jjOMV5J+xl/wTt8ffte+MbH7PpV9ovg/wA5W1DW7uAxQrED86wBgPNkI4UKCoJBYgV2RyvC4rhytPjmlSjPXldoqdraPTrfZLfTQ58DxZm2WZ7TfCGIq8ul9ZW31Wu6tvc/eOytoIrOFV+6qAD6YoqaGy8uFVz90AUV/JPuH9AKtWerLFFFFSbBQTiiigCIr5i8iuN+IPwD8FfFddviTwtoGucYH26wimKj2LKSPzoorSnWqUvfpScX3TszlxWHpVPcqRUl5q5wlr/wTl+BkNx9qj+GPg9X3bsnTkZc/wC6Rj9K9M8FfCrw38NrBbXQdD0nRbcf8s7K0jt0/JAKKK6sRmmMrx5a1WUl5yb/ADZnh8owVKXPSpRi/JI6YCiiiuE7gooooAKKKKAKGpaXbaxBJDcQR3MbjaySIGVh6EHg15Z4t/YK+Dvja8abUvhv4QuJmOS40yJGJ9cqBRRXTh8bicO70Kko+ja/I48Tl+Gr/wAaCl6pMseC/wBiP4S/Dy5W40f4d+EbC4U5WVNLhMgPqGKkivULezhsYtscaIqjACjoPSiilisZiK65q85Sfdtv8ysPgMPQV6MFH0SRaooornOo/9k=';
			doc.pageMargins = [20,60,20,30];
			// Set the font size fot the entire document
			doc.defaultStyle.fontSize = 7;
			// Set the fontsize for the table header
			doc.styles.tableHeader.fontSize = 7;
			// Create a header object with 3 columns
			// Left side: Logo
			// Middle: brandname
			// Right side: A document title
			doc['header']=(function() {
				return {
					columns: [
						{
							image: logo,
							width: 24
						},
						{
							alignment: 'left',
							italics: true,
							text: 'REPORTTITLE',
							fontSize: 18,
							margin: [10,0]
						},
						{
							alignment: 'right',
							fontSize: 14,
							text: 'iLocator - PertSol'
						}
					],
					margin: 20
				}
			});
			// Create a footer object with 2 columns
			// Left side: report creation date
			// Right side: current page and total pages
			doc['footer']=(function(page, pages) {
				return {
					columns: [
						{
							alignment: 'left',
							text: ['Created on: ', { text: jsDate.toString() }]
						},
						{
							alignment: 'right',
							text: ['page ', { text: page.toString() },	' of ',	{ text: pages.toString() }]
						}
					],
					margin: 20
				}
			});
			
			
			
			// Change dataTable layout (Table styling)
			// To use predefined layouts uncomment the line below and comment the custom lines below
			// doc.content[0].layout = 'lightHorizontalLines'; // noBorders , headerLineOnly
			var objLayout = {};
			objLayout['hLineWidth'] = function(i) { return .5; };
			objLayout['vLineWidth'] = function(i) { return .5; };
			objLayout['hLineColor'] = function(i) { return '#aaa'; };
			objLayout['vLineColor'] = function(i) { return '#aaa'; };
			objLayout['paddingLeft'] = function(i) { return 4; };
			objLayout['paddingRight'] = function(i) { return 4; };
			doc.content[0].layout = objLayout;
			},
    orientation : 'landscape',
    pageSize : 'A4',
    titleAttr : 'PDF'}
        ],
				colReorder: true, 
         "ajax": {
             "url": "/lis/lis?func=viewreport&seqid=IPDRSEQID",
             "type": "POST",
             "dataType":"json",
			error: function(){  // error handling
				$("#myTable").append('<tbody><tr><th colspan="FIELDCNT">No data found in the server</th></tr></tbody>');
				$("#myTable").css("display","none");
			}
             },
          "columnDefs": [
                            {
                                "targets": [FIELDCNT],
                                "visible": false
                            }
                        ]  
        } );
		$('.search-input-text').on( 'keyup click', function () {   // for text boxes
			var i =$(this).attr('data-column');  // getting column index
			var v =$(this).val();  // getting search input value
			dTable.columns(i).search(v).draw();
		} );
	});



		</script>
<div class="dataTables_scroll">		
		<table id="myTable" class="display" width="100%">
		    <thead>
		        <tr>
		           TABLEHEADER
		        </tr>
		    </thead>
					<thead>
					</thead>
		    
		</table> </div>
		

