#!/bin/sh
AIRTELIP=203.145.131.242
AIRTELPORT=443
VODAFONEIP=103.75.248.211
VODAFONEPORT=443
IDEAIP=112.110.32.250
IDEAPORT=10035
GOOGLEIP=8.8.8.8
GOOGLEPORT=443
SYNMNPIP=18.215.111.139
SYNMNPPORT=443
TELEMNPIP=1.1.1.1
TELEMNPPORT=443
BSNLIP=10.101.102.2
CADIP=10.100.1.142
SMSCIP=218.248.82.6
SMSCPORT=5016

date
echo  "================================================================================================";
echo  "Server Details "
echo  "================================================================================================";
hostname
uname -a
echo  "================================================================================================";
echo  "Server Uptime "
echo  "================================================================================================";
uptime
echo  "================================================================================================";
echo  "Disk Usage : Partition  Size  used Above 90% should be  reported";
echo  "================================================================================================";

df -h;
df -H | grep -vE '^Filesystem|tmpfs|cdrom|boot' | awk '{ print $6 " " $1 " " $5 }' | while read output;
do
  usep=$(echo $output | awk '{ print $3}' | cut -d'%' -f1  )
  partition=$(echo $output | awk '{ print $1 }' )
  if [ $usep -ge 80 ]; then
    echo "\"$partition :  Running out of space ($usep%)\" "
  fi
done

echo  "================================================================================================";
echo  "Disk Inodes : Partition  inodes used  Above 80% should be  reported ";
echo  "================================================================================================";
df -i;
df -i | grep -vE '^Filesystem|tmpfs|cdrom|boot' | awk '{ print $6 " " $1 " " $5 }' | while read output;
do
  usep=$(echo $output | awk '{ print $3}' | cut -d'%' -f1  )
  partition=$(echo $output | awk '{ print $1 }' )
  if [ $usep -ge 80 ]; then
    echo "\"$partition :  Running out of inodes ($usep%)\" "
  fi
done

echo  "================================================================================================";
echo  "Disk MNTRAMDISK Existence of Partition /mnt/ramdisk/ to be reported  and size should be above 50%";
echo  "================================================================================================";

df -H | grep -vE '^Filesystem|tmpfs|cdrom|boot'|grep '/mnt/ramdisk' | awk '{ print $6 " " $1 " " $5 }' | while read output;
do
echo $output
  usep=$(echo $output | awk '{ print $3}' | cut -d'%' -f1  )
  partition=$(echo $output | awk '{ print $1 }' )
  if [  -n $partition  ]; then
  echo "\"$partition : exists  on the server ";
  else
  echo "/mnt/ramdisk : not exists  on the server ";
  fi
done

echo  "================================================================================================";
echo  "Server Load Status "
echo  "================================================================================================";
sar 1 5

echo  "================================================================================================";
echo  "Server Process  Monitoring  Process  running  on  iLocator Server "
echo  "================================================================================================";
for i  in MYSQL ELS BEARER SMSBOX iLocatorWeb iLocatorWeb_gvk
do
#echo "process :$i"
#echo "================================"
if [ $i = 'MYSQL' ]; then
   record=`ps -eaf|grep mysqld_safe|grep -v grep |wc -l `
   #echo $record
   if [  $record -ge "1"  ]; then
   echo "Mysql : is  running with process count $record  ";
   else
   echo "Mysql : is not running  ";
   fi
elif [ $i = 'ELS' ]; then
   record=`ps -eaf|grep -i ELS|grep -v grep |wc -l`
   #echo $record
   if [  $record -ge "1"  ]; then
   echo "ELS : is  running with process count $record   ";
   else
   echo "ELS : is not running  ";
   fi
elif [ $i = 'BEARER' ]; then
   record=`ps -eaf|grep -i BEARERBOX|grep -v grep |wc -l`
   #echo $record
   if [  $record -ge "1"  ]; then
   echo "Bearerbox : is  running with process count $record   ";
   else
   echo "Bearerbox : is not running  ";
   fi
elif [ $i = 'SMSBOX' ]; then
   record=`ps -eaf|grep -i SMSBOX|grep -v grep |wc -l`
   #echo $record
   if [  $record -ge "1"  ]; then
   echo "SMSBOX : is  running  with process count $record ";
   else
   echo "SMSBOX : is not running  ";
   fi
elif [ $i = 'iLocatorWeb' ]; then
   record=`ps -eaf|grep -i iLocatorWeb.pl|grep -v grep |wc -l`
   #echo $record
   if [  $record -ge "1" -a $record -le "30" ]; then
   echo "ILOCATORWEB : is  running with process count $record ";
   elif [  $record -ge "31"  ]; then
   echo "ILOCATORWEB.PL : is  running with process count $record ------ DANGER  ";
   else
   echo "ILOCATORWEB.PL : is not running  ";
   fi
elif [ $i = 'iLocatorWeb_gvk' ]; then
   record=`ps -eaf|grep -i iLocatorWeb_gvk_7475.pl|grep -v grep |wc -l`
   #echo $record
   if [  $record -ge "1" -a $record -le "39" ]; then
   echo "ILOCATORWEB_GVK : is  running with process count $record ";
   elif [  $record -ge "40"  ]; then
   echo "ILOCATORWEB_GVK_7475.pl : is  running with process count $record ------ DANGER  ";
   else
   echo "ILOCATORWEB_GVK_7475.pl : is not running  ";
   fi
fi
done

echo  "================================================================================================";
echo  "Connectivity Status :Connectivity  test  to  NETWORK ELEMENTS from PRIMARY SERVER "
echo  "================================================================================================";
for i  in  AIRTEL VODAFONE IDEA GOOGLE SYNMNP TELEMNP  BSNL CAD SMSC
do
#echo "$i"
#echo "=================="
if [ $i = 'AIRTEL' ]; then
   record=`nc -zw1 $AIRTELIP $AIRTELPORT|grep succeeded|awk -F" " '{print $1}'`
   #echo $record
   if [  -n "$record"  ]; then
   echo "$i : $AIRTELIP is Reachable  and login on Port : $AIRTELPORT OCCURING ";
   else
   echo "$i : $AIRTELIP is not Reachable  ";
   fi
elif [ $i = 'VODAFONE' ]; then
   record=`nc -zw1 $VODAFONEIP $VODAFONEPORT|grep succeeded|awk -F" " '{print $1}'`
   #echo $record
   if [  -n "$record"  ]; then
   echo "$i : $VODAFONEIP is Reachable  and login on Port : $VODAFONEPORT OCCURING ";
   else
   echo "$i : $VODAFONEIP is not Reachable  ";
   fi
elif [ $i = 'IDEA' ]; then
   record=`nc -zw1 $IDEAIP $IDEAPORT|grep succeeded|awk -F" " '{print $1}'`
   #echo $record
   if [  -n "$record"  ]; then
   echo "$i : $IDEAIP is Reachable  and login on Port : $IDEAPORT OCCURING ";
   else
   echo "$i : $IDEAIP is not Reachable  ";
   fi
elif [ $i = 'GOOGLE' ]; then
   record=`nc -zw1 $GOOGLEIP $GOOGLEPORT|grep succeeded |awk -F" " '{print $1}'`
   #echo $record
   if [  -n "$record"  ]; then
   echo "$i : $GOOGLEIP is Reachable  and login on Port : $GOOGLEPORT OCCURING ";
   else
   echo "$i : $GOOGLEIP is not Reachable  ";
   fi
elif [ $i = 'SYNMNP' ]; then
   record=`nc -zw1 $SYNMNPIP $SYNMNPPORT|grep succeeded |awk -F" " '{print $1}'`
   #echo $record
   if [  -n "$record"  ]; then
   echo "$i : $SYNMNPIP is Reachable  and login on Port : $SYNMNPPORT OCCURING ";
   else
   echo "$i : $SYNMNPIP is not Reachable  ";
   fi
elif [ $i = 'TELEMNP' ]; then
   record=`nc -zw1 $SYNMNPIP $SYNMNPPORT|grep succeeded |awk -F" " '{print $1}'`
   #echo $record
   if [  -n "$record"  ]; then
   echo "$i : $TELEMNPIP is Reachable  and login on Port : $TELEMNPPPORT OCCURING ";
   else
   echo "$i : $TELEMNPIP is not Reachable  ";
   fi
elif [ $i = 'BSNL' ]; then
    if ping -q -c 1 -W 1 $BSNLIP >/dev/null; then
        echo "BSNL : $BSNLIP is up"
        else
        echo "BSNL : $BSNLIP is not Reachable "
        fi
elif [ $i = 'CAD' ]; then
    if ping -q -c 1 -W 1 $CADIP >/dev/null; then
        echo "CAD : $CADIP is up"
        else
        echo "CAD : $CADIP is not Reachable "
        fi
elif [ $i = 'SMSC' ]; then
    reorcd=`netstat -an|grep 5016|grep ESTABLISHED`
    if [  -n "$record"  ]; then
    echo "$i : $SMSCIP is Reachable  and login on Port : $SMSCPPORT OCCURING ";
    else
    echo "$i : $SMSCIP is not Reachable  ";
    fi
fi
done

echo  "================================================================================================";
echo  " MNP MCH1 (SYNIVERSE) SERVER STATUS  Next Expiry on 03-May-2019 "
echo  "================================================================================================";
cd /root/lbs/mnp/logs
filelast=`ls -ltr mnp.log |awk -F" " '{print $6" " $7" " $8}'`
echo "File Last Update  at : $filelast "
filerecord=`tail -20 mnp.log|grep  'Error Code 500' |wc -l`
   if [  $filerecord -ge "5"  ]; then
   echo "MNP  GUI  PASSWORD has  expired , Stop  MNP  query  from getaddress.sh and  change  password ";
   else
   echo "MNP GUI MCH1 working properly  ";
   fi

echo  "================================================================================================";
echo  "Last Successful Location Time by Operator "
echo  "================================================================================================";
echo  "Operator,RequestTime"
for i in Airtel Vodafone Idea Tata Aircel Uninor RCom Jio BSNL_LL BSNL
do
        mysql -N ilocate << EOT
        select "$i",max(requesttime) from accesslog where requesttime > date_add(now(),interval -1 day) and operator = '$i' and locresponse <> '0,0';
EOT
done

echo  "================================================================================================";
echo  "Last Successful ELS Location Time by Operator "
echo  "================================================================================================";
echo  "Operator,RequestTime"
for i in Airtel Vodafone Idea Tata Aircel Uninor RCom Jio BSNL_LL BSNL
do
        mysql -N ilocate << EOT
        select "$i",max(requesttime) from accesslog where requesttime > date_add(now(),interval -1 day) and operator like 'E%$i' and locresponse <> '0,0';
EOT
done
echo  "================================================================================================";
echo  "ELS Location Where Operator Not Identified "
echo  "================================================================================================";
echo  "Operator,RequestTime"
for i in EL EH
do
        mysql -N ilocate << EOT
        select "$i",max(requesttime) from accesslog where requesttime > date_add(now(),interval -1 day) and operator = '$i' and locresponse <> '0,0';
EOT
done

echo  "================================================================================================";
echo  "Last Address Data Update Date by Folder "
echo  "================================================================================================";
ls -l //mnt/ramdisk/workarea/

