<script type="text/javascript">
	
	function getQueryParams(qs) {
	    qs = qs.split('+').join(' ');

	    var params = {},
	        tokens,
	        re = /[?&]?([^=]+)=([^&]*)/g;

	    while (tokens = re.exec(qs)) {
	        params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
	    }

	    return params;
	}

	//var query = getQueryParams(document.location.search);
	//alert(query.foo);
function format ( rowData ) {
	var div = $('<div/>')
		.addClass( 'loading' )
		.text( 'Loading...' );

	$.ajax( {
		url: '/lis/lis?func=GetUserOpt&form=ListTarget',
		data: {
			liid: rowData.liid
		},
		dataType: 'json',
		type: 'post',
		success: function ( json ) {
			div
				.html( json.html )
				.removeClass( 'loading' );
		} 
	} );

	return div;
}


$(document).ready(function() {
	var query = getQueryParams(document.location.search);
	
	$('#myTable tfoot th').each( function (i) {
	         var title = $('#myTable thead th').eq( $(this).index() ).text();
			if(title != '')
			{
	        $(this).html( '<input type="text" size="10" placeholder="Search '+title+'" data-index="'+i+'"/>' );
		}
	    } );
		
	
	var table = $('#myTable').DataTable( {
		"ajax": "/lis/lis?func=ListTarget&leaname="+query.leaname+"&mc="+query.mcname,
		"columns": [
			{
				"className":      'details-control',
				"orderable":      false,
				"data":           null,
				"defaultContent": ''
			},
			{ "data": "targetid" },
			{ "data": "targettype" },
			{ "data": "liid" },
			{ "data": "leaname" },
			{ "data": "configname" },
			{ "data": "targetstatus" },
			{ "data": "fanoutmode" },
			{ "data": "fanoutno" },
			{ "data": "targetend" },
			{ "data": "targetstart" },
			{ "data": "targetreqdt" },
			{ "data": "warrantdetails" },
			{ "data": "createdate" }
		],
		"order": [[2, 'asc']],
		dom: 'Bfrtip',
		scrollX:        true,
		 stateSave: false,
		 scrollCollapse: true,
		fixedColumns:   true,
        buttons: [
            {
                extend: 'colvis',
                collectionLayout: 'fixed two-column'
            },
			{
			                extend: 'pdfHtml5',
			                messageTop: 'Target Report - Custom'
			},
			{
			            extend: 'excelHtml5',
			}
        ],
	} );
	
	
 
	    // DataTable
	    
 
	    // Apply the search
		$( table.table().container() ).on( 'keyup', 'tfoot input', function () {
		        table
		            .column( $(this).data('index') )
		            .search( this.value )
		            .draw();
		    } );
		
	// Add event listener for opening and closing details
	$('#myTable tbody').on('click', 'td.details-control', function () {
		var tr = $(this).closest('tr');
		var row = table.row( tr );

		if ( row.child.isShown() ) {
			// This row is already open - close it
			row.child.hide();
			tr.removeClass('shown');
		}
		else {
			// Open this row
			row.child( format(row.data()) ).show();
			tr.addClass('shown');
		}
	} );
} );

		</script>
		
		<table id="myTable" class="stripe row-border order-column" width="50%">
		    <thead>
		        <tr>
		            <th></th>
					<th>Target No</th>
					<th>Target Type</th>
					<th>LIID</th>
					<th>LEA Name</th>
					<th>MC Config</th>
					<th>Target Status</th>
					<th>Fanout Mode</th>
					<th>Fanout No</th>
					<th>Target End</th>
					<th>Target Start</th>
					<th>Request Date</th>
					<th>Warrant Details</th>
					<th>Create Date</th>
		        </tr>
		        
		    </thead>
		    <tfoot>
				<tr>
		            <th></th>
					<th>Target No</th>
					<th>Target Type</th>
					<th>LIID</th>
					<th>LEA Name</th>
					<th>MC Config</th>
					<th>Target Status</th>
					<th>Fanout Mode</th>
					<th>Fanout No</th>
					<th>Target End</th>
					<th>Target Start</th>
					<th>Request Date</th>
					<th>Warrant Details</th>
					<th>Create Date</th>
		        </tr>
		    </tfoot>
		

		    
		</table>