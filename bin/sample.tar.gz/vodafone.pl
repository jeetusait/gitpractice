#!/usr/bin/perl

use warnings;
use strict;
use Data::Dumper;
use XML::Compile::Schema;
use XML::LibXML::Reader;
use XML::Twig;
use IO::File;
use LWP::UserAgent;
use HTTP::Request::Common;
use Try::Tiny;
use Term::ReadPassword::Win32 qw(read_password);
use POSIX qw(strftime);
use JSON;


#my $password = read_password("Password: ");

#if($password eq "airtest21" )
#{
#	print "Continuing ... \n";
#}
#else
#{
	#die "Incorrect Password \n";
#}

sub replace_xml_tagval
{
	my ($doc,$fieldname,$fieldval)=@_;
	my $root=$doc->getDocumentElement;
	my ($node)=$root->findnodes($fieldname);
	$node->removeChildNodes();
	$node->appendText($fieldval);
}

sub replace_xml_fieldval
{
	my ($doc,$fieldname,$fieldval)=@_;
	my $root=$doc->getDocumentElement;
	my ($node)=$root->findnodes($fieldname);
	$node->setValue($fieldval);
}

my $PID;
local $SIG{ALRM} = sub {open my $fh1, ">>", 'logs/logfilevodafone.txt.'.strftime('%y%m%d%H',localtime) ; print $fh1 "Script Killed for ".$ARGV[0]."\n";print "Error";kill -9, $$;};
alarm 45;


my $req_msg='<LV_LBS_MW_MSG Ver=\'2.2.2\'>
<APP_ID>LuPolice</APP_ID>
<APP_PWD>LuPolice@Jan17</APP_PWD>
<GET_POSITION_COORDINATES_REQ>
<MSISDN>919029005445</MSISDN>
</GET_POSITION_COORDINATES_REQ>
</LV_LBS_MW_MSG>';

my %url;

#80b0c7dbc80ce1f077ad277590c6e6825df342f0:b8e9a99581d080adccf82b5bffeac6691052c95f
#ODBiMGM3ZGJjODBjZTFmMDc3YWQyNzc1OTBjNmU2ODI1ZGYzNDJmMDpiOGU5YTk5NTgxZDA4MGFkY2NmODJiNWJmZmVhYzY2OTEwNTJjOTVm

my $header1 = new HTTP::Headers (
    'Content-Type'   => 'application/x-www-form-urlencoded',
    'User-Agent'     => 'iLocator',
	'Authorization' => 'Basic YTYxYWRmZjk4ZTNjNDE5OWUwOWM3MDFiMTM4NmRmMDk6WWgqRzRaKzY=',
);



my ($req,$res);

#my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 } );
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0,SSL_ca_file=>'/root/lbs/tata/partner_vodafoneidea_com.crt', } );
my $doc;

open my $fh, ">>", 'logs/logfilevodafone.txt.'.strftime('%y%m%d%H',localtime) ;


#$url{"vodafone"}="https://api.vodafoneidea.com/services2/asegetlocation/2_0/location/queries/location?address=tel:+".$ARGV[0]."&requestedAccuracy=100";

$url{"vodafone"}="https://partner.vodafoneidea.com/services2/asegetlocation/2_0/location/queries/location?address=tel:+".$ARGV[0]."&requestedAccuracy=100";

#$url{"airtel1"}="http://203.145.131.242/apigw/airtel/terminalLocation/v1/getLocation?address=tel:919937292274&requestedAccuracy=1000";

#my $parser = XML::LibXML->new;

#$doc=$parser->parse_string($req_msg);
#replace_xml_tagval($doc,'//MSISDN',$ARGV[0]);

$req = new HTTP::Request('GET',$url{"vodafone"},$header1,'');
$res = $ua->request($req);

#print "############## Debug Request #################\n";
#print $req->as_string."\n";
#print "###############################################\n";

#print "############## Debug Response #################\n";
#print $res->as_string."\n";
#print "###############################################\n";

my $response=decode_json($res->content);

if(defined $response->{'terminalLocationList'}->{'terminalLocation'}[0]->{'currentLocation'}->{'latitude'})
{
print $response->{'terminalLocationList'}->{'terminalLocation'}[0]->{'currentLocation'}->{'latitude'}.",".$response->{'terminalLocationList'}->{'terminalLocation'}[0]->{'currentLocation'}->{'longitude'};
print $fh "LBSREC,SUCCESS,VODAFONE,".$ARGV[0].",\n";
}
else
{
my $response=decode_json($res->content);
my $err1=$response->{'requestError'}->{'serviceException'}->{'text'};
print "Error";
print $fh "LBSREC,ERROR,VODAFONE,".$ARGV[0].",$err1\n";
}


print $fh "############## Debug Request #################\n";
print $fh  $req->as_string."\n";
print  $fh "###############################################\n";

print  $fh "############## Debug Response #################\n";
print $fh $res->as_string."\n";
print  $fh "###############################################\n";




#$doc=$parser->parse_string($res->content);

#my $latitude=$doc->find('//LATITUDE');
#my $longitude=$doc->find('//LONGITUDE');

#print "\n Latitude is ".$doc->find('//LATITUDE');
#print "\n Longitude is ".$doc->find('//LONGITUDE');

#print "\nGoogle URL : http://maps.google.com/maps?q=$latitude,$longitude\n";
