#!/usr/bin/perl

use warnings;
use strict;
use Data::Dumper;
use XML::Compile::Schema;
use XML::LibXML::Reader;
use XML::Twig;
use IO::File;
use LWP::UserAgent;
use HTTP::Request::Common;
use Try::Tiny;
use Term::ReadPassword::Win32 qw(read_password);
use JSON;
use POSIX qw(strftime);
use DBI;

open my $fh, ">>", 'logs/logfilebsnl.txt.'.strftime('%y%m%d',localtime) ;


my $header1 = new HTTP::Headers (
    'Content-Type'   => 'application/x-www-form-urlencoded',
    'User-Agent'     => 'iLocator',
);

my $vmsisdn=$ARGV[0];

if(length($vmsisdn)==10)
{
        $vmsisdn='91'.$vmsisdn;
}

#my $url="http://127.0.0.1:8089/restcomm/gmlc/rest?msisdn=$vmsisdn";
my $url="http://117.249.1.38:9099/getlocation?username=mp100&password=Mpb%230310&msisdn=$vmsisdn";

my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 } );

my $req = new HTTP::Request('GET',$url,$header1,'');
my $res = $ua->request($req);

print $fh "############## Debug Request : ".$vmsisdn." #################\n";
print  $fh $req->as_string."\n";
print  $fh "###############################################\n";

print  $fh "############## Debug Response : ".$vmsisdn." #################\n";
print  $fh $res->as_string."\n";
print  $fh "###############################################\n";


#print "############## Debug Request #################\n";
#print $req->as_string."\n";
#print "###############################################\n";

#print "############## Debug Response #################\n";
#print $res->as_string."\n";
#print "###############################################\n";

#print "############## Debug Response response #################\n";

my $response=decode_json($res->content);

#print Dumper($response);

my $long=$response->{'longitude'} ;
#print $response->{'longitude'};
#print $response->{'latitude'};

if( $response->{'longitude'}  > 0 )
{
       print $response->{'latitude'}.",".$response->{'longitude'};
       print $fh "LBSREC,SUCCESS,BSNL,".$vmsisdn.",".$response->{'ageOfLocationEstimate'};
}
else
{

       my $err1=$response->{'error'};
       print "Error\n";
       print $fh "LBSREC,ERROR,BSNL,".$vmsisdn.",$err1\n";
       die;
}

