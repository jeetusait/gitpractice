#!/bin/sh
cd /root/lbs/tata
token=`cat .airtel_token`
if [ -z "$token" ]
then
	token=`./airtel.pl`
	echo $token > .airtel_token
fi
ans=`./airtel1.pl $token $1`
if [ "$ans" = "TokenError" ]
then
	token=`./airtel.pl`
	echo $token > .airtel_token
	ans=`./airtel1.pl $token $1`
fi

echo $ans

