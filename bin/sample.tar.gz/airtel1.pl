#!/usr/bin/perl

use warnings;
use strict;
use Data::Dumper;
use XML::Compile::Schema;
use XML::LibXML::Reader;
use XML::Twig;
use IO::File;
use LWP::UserAgent;
use HTTP::Request::Common;
use Try::Tiny;
use Term::ReadPassword::Win32 qw(read_password);
use JSON;
use POSIX qw(strftime);

sub replace_xml_tagval
{
	my ($doc,$fieldname,$fieldval)=@_;
	my $root=$doc->getDocumentElement;
	my ($node)=$root->findnodes($fieldname);
	$node->removeChildNodes();
	$node->appendText($fieldval);
}

sub replace_xml_fieldval
{
	my ($doc,$fieldname,$fieldval)=@_;
	my $root=$doc->getDocumentElement;
	my ($node)=$root->findnodes($fieldname);
	$node->setValue($fieldval);
}

my $PID;
local $SIG{ALRM} = sub {open my $fh1, ">>", 'logs/logfileairtel.txt.'.strftime('%y%m%d%H',localtime) ; print $fh1 "Script Killed for ".$ARGV[1]."\n";print "";kill -9,$$;};
alarm 60;
my $req_msg='<LV_LBS_MW_MSG Ver=\'2.2.2\'>
<APP_ID>LuPolice</APP_ID>
<APP_PWD>LuPolice@Jan17</APP_PWD>
<GET_POSITION_COORDINATES_REQ>
<MSISDN>919029005445</MSISDN>
</GET_POSITION_COORDINATES_REQ>
</LV_LBS_MW_MSG>';

my %url;

#80b0c7dbc80ce1f077ad277590c6e6825df342f0:b8e9a99581d080adccf82b5bffeac6691052c95f
#ODBiMGM3ZGJjODBjZTFmMDc3YWQyNzc1OTBjNmU2ODI1ZGYzNDJmMDpiOGU5YTk5NTgxZDA4MGFkY2NmODJiNWJmZmVhYzY2OTEwNTJjOTVm

my $header1 = new HTTP::Headers (
    'Content-Type'   => 'application/x-www-form-urlencoded',
    'User-Agent'     => 'iLocator',
	'Authorization' => 'Basic M2EzMDA0YzMwMzA2Mjc4Zjk2OGY0YzFhZDFjZGYyY2Y5NWMyMTVmNToxOTQzNTVjYTg4ZDBkY2I4NmRmMWM2MWJkYWQyNDU3YzQ4MGRmMDRk',
);

my $header2 = new HTTP::Headers (
    'Content-Type'   => 'application/x-www-form-urlencoded',
    'User-Agent'     => 'iLocator',
    'serviceId'     => '4847',
    'providerId'     => '623',
	'Accept'	=> 'application/json',
	'Cache-Control'	=> 'no-cache',
'Authorization' => 'Bearer '.$ARGV[0],
);



my ($req,$res);

my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 } );
my $doc;

open my $fh, ">>", 'logs/logfileair.txt.'.strftime('%y%m%d%H',localtime) ;


$url{"airtel"}="https://203.145.131.242/oauth/token?grant_type=client_credentials"; 
$url{"airtel2"}="http://203.145.131.242/apigw/airtel/ssm/v1/subscribe?msisdn=".$ARGV[1];
$url{"airtel1"}="http://203.145.131.242/apigw/airtel/terminalLocation/v1/getLocation?address=tel:".$ARGV[1]."&requestedAccuracy=100";

#my $parser = XML::LibXML->new;

#$doc=$parser->parse_string($req_msg);
#replace_xml_tagval($doc,'//MSISDN',$ARGV[0]);

$req = new HTTP::Request('GET',$url{"airtel2"},$header2,'');
$res = $ua->request($req);

print $fh "############## Debug Request #################\n";
print  $fh $req->as_string."\n";
print  $fh "###############################################\n";

print  $fh "############## Debug Response #################\n";
print  $fh $res->as_string."\n";
print  $fh "###############################################\n";

#print "############## Debug Request #################\n";
#print $req->as_string."\n";
#print "###############################################\n";

#print "############## Debug Response #################\n";
#print $res->as_string."\n";
#print "###############################################\n";

if($res->content =~ /Invalid Access/)
{
	print "TokenError\n"; 
	die;
}

sleep 4;

$req = new HTTP::Request('GET',$url{"airtel1"},$header2,'');
$res = $ua->request($req);

print $fh "############## Debug Request #################\n";
print  $fh $req->as_string."\n";
print  $fh "###############################################\n";

print  $fh "############## Debug Response #################\n";
print  $fh $res->as_string."\n";
print  $fh "###############################################\n";

if($res->content =~ /serviceError/)
{
	$url{"airtel1"}="http://203.145.131.242/apigw/airtel/terminalLocation/v1/getLocation?address=tel:".$ARGV[1]."&requestedAccuracy=1000";
	$req = new HTTP::Request('GET',$url{"airtel1"},$header2,'');
	$res = $ua->request($req);
	print $fh "############## Debug Request #################\n";
	print  $fh $req->as_string."\n";
	print  $fh "###############################################\n";

	print  $fh "############## Debug Response #################\n";
	print  $fh $res->as_string."\n";
	print  $fh "###############################################\n";

	
	if($res->content =~ /serviceError/)
	{
		if($res->content =~ /CellIdNotFoundException/)
		{

			my $response=decode_json($res->content);
			my $err1=$response->{'requestError'}->{'serviceError'}->{'text'};
			my @cell=split /:/,$err1;	
			my $cellid=$cell[2];
			#print "Cell ID is :".$cell[2]."\n";
			my $latlong=`/root/lbs/tata/getlatlong.sh $cellid`;
			if ( $latlong eq '' )
			{
				print "Error\n";
       			         print $fh "LBSREC,ERROR,AIRTEL,".$ARGV[1].",cellid_$cellid\n";
                		die;
	
			}
			else
			{
				print $latlong;
				print $fh "LBSREC,SUCCESS,AIRTEL,".$ARGV[1].",cellid_$cellid\n";
			}
		}
		else
		{
		my $response=decode_json($res->content);
                        my $err1=$response->{'requestError'}->{'serviceError'}->{'text'};
		print "Error\n";
		print $fh "LBSREC,ERROR,AIRTEL,".$ARGV[1].",$err1\n";
		die;
		}
	}
	else
	{
		my $response=decode_json($res->content);
		#print Dumper($response);
		if($response->{'result'}->{'longitude'}>0)
		{
		print $response->{'result'}->{'longitude'}.",".$response->{'result'}->{'latitude'}.",".$response->{'result'}->{'accuracy'}.",".$response->{'result'}->{'altitude'};
		print $fh "LBSREC,SUCCESS,AIRTEL,".$ARGV[1].",1000\n";
		}
		else
		{

			print "Error";
			print $fh "LBSREC,ERROR,AIRTEL,".$ARGV[1].",\n";
		}

	}
}
else
{
	my $response=decode_json($res->content);
	#print Dumper($response);
	if($response->{'result'}->{'longitude'}>0)
                {
	print $response->{'result'}->{'longitude'}.",".$response->{'result'}->{'latitude'}.",".$response->{'result'}->{'accuracy'}.",".$response->{'result'}->{'altitude'};
	print $fh "LBSREC,SUCCESS,AIRTEL,".$ARGV[1].",400\n";
	}
                else
                {
			END:

                        print "Error";
                        print $fh "LBSREC,ERROR,AIRTEL,".$ARGV[1].",\n";
                }

	
}








#$doc=$parser->parse_string($res->content);

#my $latitude=$doc->find('//LATITUDE');
#my $longitude=$doc->find('//LONGITUDE');

#print "\n Latitude is ".$doc->find('//LATITUDE');
#print "\n Longitude is ".$doc->find('//LONGITUDE');

#print "\nGoogle URL : http://maps.google.com/maps?q=$latitude,$longitude\n";






